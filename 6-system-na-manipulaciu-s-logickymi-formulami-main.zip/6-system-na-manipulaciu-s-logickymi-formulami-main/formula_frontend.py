from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class ExprNode:
    op: str
    value: str | None = None
    left: "ExprNode | None" = None
    right: "ExprNode | None" = None


OPS = {
    "and": lambda l, r: l and r,
    "or": lambda l, r: l or r,
    "imp": lambda l, r: (not l) or r,
    "iff": lambda l, r: l == r,
}


def prolog_ast_to_exprnode(ast: Any) -> ExprNode:
    """
    Convert SWI-Prolog AST from pyswip (usually str like 'imp(var(A), var(B))')
    into ExprNode for visualization and truth-table evaluation.
    """
    if isinstance(ast, str):
        text = ast.strip()
        if not text:
            raise ValueError("Empty AST from Prolog.")
        node, end = _parse_prolog_term(text, 0)
        end = _skip_ws(text, end)
        if end != len(text):
            raise ValueError(f"Trailing junk in AST after position {end}: {text!r}")
        return node
    text = str(ast).strip()
    return prolog_ast_to_exprnode(text)


def _skip_ws(s: str, i: int) -> int:
    while i < len(s) and s[i].isspace():
        i += 1
    return i


def _read_ident(s: str, i: int) -> tuple[str, int]:
    i = _skip_ws(s, i)
    if i >= len(s):
        raise ValueError("Unexpected end while reading identifier.")
    if not (s[i].isalpha() or s[i] == "_"):
        raise ValueError(f"Expected identifier at {i}, got {s[i]!r} in {s!r}")
    start = i
    while i < len(s) and (s[i].isalnum() or s[i] == "_"):
        i += 1
    return s[start:i], i


def _parse_arg_list(s: str, i: int) -> tuple[list[ExprNode], int]:
    args: list[ExprNode] = []
    while True:
        i = _skip_ws(s, i)
        if i >= len(s):
            raise ValueError("Unterminated argument list.")
        if s[i] == ")":
            i += 1
            return args, i
        arg, i = _parse_prolog_term(s, i)
        args.append(arg)
        i = _skip_ws(s, i)
        if i < len(s) and s[i] == ",":
            i += 1
            continue
        if i < len(s) and s[i] == ")":
            i += 1
            return args, i
        raise ValueError(f"Expected ',' or ')' in AST at {i}: {s!r}")


def _parse_prolog_term(s: str, i: int) -> tuple[ExprNode, int]:
    name, i = _read_ident(s, i)
    i = _skip_ws(s, i)
    if i < len(s) and s[i] == "(":
        i += 1
        args, i = _parse_arg_list(s, i)
        if name == "var":
            if len(args) != 1:
                raise ValueError(f"var/1 expected one argument, got {len(args)} in {s!r}")
            inner = args[0]
            if inner.op == "var" and inner.value is not None:
                return inner, i
            raise ValueError(f"var(...) expects a variable name inside, got {inner!r}")
        if name == "not":
            if len(args) != 1:
                raise ValueError(f"not/1 expected one argument in {s!r}")
            return ExprNode("not", left=args[0]), i
        if name in OPS:
            if len(args) != 2:
                raise ValueError(f"{name}/2 expected two arguments in {s!r}")
            return ExprNode(name, left=args[0], right=args[1]), i
        raise ValueError(f"Unknown functor in AST: {name}/{len(args)} in {s!r}")

    lower = name.lower()
    if lower in {"true", "false"}:
        return ExprNode("const", value=lower), i
    return ExprNode("var", value=name), i


def extract_variables(expr: ExprNode) -> set[str]:
    if expr.op == "const":
        return set()
    if expr.op == "var" and expr.value is not None:
        return {expr.value}
    if expr.op == "not" and expr.left is not None:
        return extract_variables(expr.left)
    if expr.left is not None and expr.right is not None:
        return extract_variables(expr.left) | extract_variables(expr.right)
    return set()


def evaluate_expr(expr: ExprNode, assignment: dict[str, bool]) -> bool:
    if expr.op == "const" and expr.value is not None:
        return expr.value == "true"
    if expr.op == "var" and expr.value is not None:
        return assignment[expr.value]
    if expr.op == "not" and expr.left is not None:
        return not evaluate_expr(expr.left, assignment)
    if expr.op in OPS and expr.left is not None and expr.right is not None:
        left_value = evaluate_expr(expr.left, assignment)
        right_value = evaluate_expr(expr.right, assignment)
        return OPS[expr.op](left_value, right_value)
    raise ValueError("Invalid expression tree.")


def build_normal_form_table(
    formula: str,
    parse_expr: Callable[[str], ExprNode],
    normal_form: str,
    source_formula: str | None = None,
) -> tuple[list[dict[str, str]], dict[str, str | int]]:
    expr = parse_expr(formula)

    if normal_form == "cnf":
        outer_op = "and"
        inner_op = "or"
        row_label = "Clause"
        row_prefix = "C"
        join_symbol = "∧"
    elif normal_form == "dnf":
        outer_op = "or"
        inner_op = "and"
        row_label = "Term"
        row_prefix = "T"
        join_symbol = "∨"
    else:
        raise ValueError(f"Unsupported normal form: {normal_form}")

    groups = _flatten_associative(expr, outer_op)
    rows: list[dict[str, str]] = []
    total_literals = 0
    variables = sorted(extract_variables(expr))
    if not variables and source_formula is not None:
        variables = sorted(extract_variables(parse_expr(source_formula)))

    for index, group in enumerate(groups, start=1):
        literals = _flatten_associative(group, inner_op)
        literal_texts = [_expr_to_pretty(literal) for literal in literals]
        total_literals += len(literal_texts)
        rows.append(
            {
                row_label: f"{row_prefix}{index}",
                "Expression": _expr_to_pretty(group),
                "Literals": ", ".join(literal_texts),
                "Count": str(len(literal_texts)),
            }
        )

    summary: dict[str, str | int] = {
        "row_label": row_label,
        "row_prefix": row_prefix,
        "join_symbol": join_symbol,
        "group_count": len(rows),
        "literal_count": total_literals,
        "variable_count": len(variables),
        "variables": ", ".join(variables) if variables else "—",
    }
    return rows, summary


def build_karnaugh_map(
    formula: str,
    parse_expr: Callable[[str], ExprNode],
    normal_form: str,
    source_formula: str | None = None,
) -> dict[str, Any]:
    expr = parse_expr(formula)
    variables = sorted(extract_variables(expr))
    if not variables:
        if source_formula is not None:
            variables = sorted(extract_variables(parse_expr(source_formula)))
    if not variables:
        raise ValueError("No variables detected in formula.")
    if len(variables) > 6:
        raise ValueError("Karnaugh maps are currently supported for up to 6 variables.")

    col_var_count = (len(variables) + 1) // 2
    col_vars = variables[:col_var_count]
    row_vars = variables[col_var_count:]
    col_codes = _gray_code_tuples(len(col_vars))
    row_codes = _gray_code_tuples(len(row_vars))
    row_labels = [_bits_to_label(bits) for bits in row_codes] or ["0"]
    col_labels = [_bits_to_label(bits) for bits in col_codes] or ["0"]

    group_specs = _extract_karnaugh_group_specs(expr, normal_form)
    palette = [
        "#38bdf8",
        "#22c55e",
        "#f59e0b",
        "#a855f7",
        "#ef4444",
        "#14b8a6",
        "#f97316",
        "#6366f1",
    ]

    cells_by_position: dict[tuple[int, int], dict[str, Any]] = {}
    for row_index, row_bits in enumerate(row_codes):
        for col_index, col_bits in enumerate(col_codes):
            assignment = {
                **{var: bit for var, bit in zip(row_vars, row_bits)},
                **{var: bit for var, bit in zip(col_vars, col_bits)},
            }
            value = evaluate_expr(expr, assignment)
            cell_index = int(
                "".join("1" if assignment[var] else "0" for var in variables),
                2,
            )
            cells_by_position[(row_index, col_index)] = {
                "row": row_index,
                "col": col_index,
                "value": "1" if value else "0",
                "index": str(cell_index),
                "groups": [],
            }

    group_legend: list[dict[str, Any]] = []
    row_count = len(row_codes)
    col_count = len(col_codes)
    for group_index, group in enumerate(group_specs):
        color = palette[group_index % len(palette)]
        positions = [
            (row_index, col_index)
            for row_index, row_bits in enumerate(row_codes)
            for col_index, col_bits in enumerate(col_codes)
            if _matches_group_spec(
                {
                    **{var: bit for var, bit in zip(row_vars, row_bits)},
                    **{var: bit for var, bit in zip(col_vars, col_bits)},
                },
                group["spec"],
            )
        ]
        position_set = set(positions)
        group_legend.append(
            {
                "id": group["id"],
                "expression": group["expression"],
                "color": color,
                "rects": _group_rects_from_positions(positions, row_count, col_count),
            }
        )

        for row_index, col_index in positions:
            memberships = cells_by_position[(row_index, col_index)]["groups"]
            memberships.append(
                {
                    "id": group["id"],
                    "color": color,
                    "slot": len(memberships),
                    "top": row_index == 0 or (row_index - 1, col_index) not in position_set,
                    "right": col_index == col_count - 1 or (row_index, col_index + 1) not in position_set,
                    "bottom": row_index == row_count - 1 or (row_index + 1, col_index) not in position_set,
                    "left": col_index == 0 or (row_index, col_index - 1) not in position_set,
                }
            )

    return {
        "normal_form": normal_form,
        "variables": variables,
        "row_vars": row_vars,
        "col_vars": col_vars,
        "row_labels": row_labels,
        "col_labels": col_labels,
        "rows": row_count,
        "cols": col_count,
        "focus_value": "1" if normal_form == "dnf" else "0",
        "cells": [
            cells_by_position[(row_index, col_index)]
            for row_index in range(row_count)
            for col_index in range(col_count)
        ],
        "groups": group_legend,
    }


def _flatten_associative(expr: ExprNode, op: str) -> list[ExprNode]:
    if expr.op != op:
        return [expr]

    items: list[ExprNode] = []
    if expr.left is not None:
        items.extend(_flatten_associative(expr.left, op))
    if expr.right is not None:
        items.extend(_flatten_associative(expr.right, op))
    return items


def _expr_to_pretty(expr: ExprNode, parent_prec: int = -1) -> str:
    precedence = {
        "iff": 0,
        "imp": 1,
        "or": 2,
        "and": 3,
        "not": 4,
        "var": 5,
        "const": 5,
    }

    if expr.op == "var" and expr.value is not None:
        text = expr.value
    elif expr.op == "const" and expr.value is not None:
        text = "⊤" if expr.value == "true" else "⊥"
    elif expr.op == "not" and expr.left is not None:
        child = _expr_to_pretty(expr.left, precedence["not"])
        text = f"¬{child}"
    elif expr.op in {"and", "or", "imp", "iff"} and expr.left is not None and expr.right is not None:
        symbol = {
            "and": "∧",
            "or": "∨",
            "imp": "⇒",
            "iff": "⇔",
        }[expr.op]
        left_text = _expr_to_pretty(expr.left, precedence[expr.op])
        right_text = _expr_to_pretty(expr.right, precedence[expr.op] + (1 if expr.op in {"imp", "iff"} else 0))
        text = f"{left_text} {symbol} {right_text}"
    else:
        text = _op_label(expr.op)

    expr_prec = precedence.get(expr.op, 6)
    if expr_prec < parent_prec:
        return f"({text})"
    return text


def _gray_code_tuples(bit_count: int) -> list[tuple[bool, ...]]:
    if bit_count == 0:
        return [tuple()]
    return [
        tuple(bool((gray >> shift) & 1) for shift in range(bit_count - 1, -1, -1))
        for gray in (value ^ (value >> 1) for value in range(1 << bit_count))
    ]


def _bits_to_label(bits: tuple[bool, ...]) -> str:
    if not bits:
        return "0"
    return "".join("1" if bit else "0" for bit in bits)


def _extract_karnaugh_group_specs(expr: ExprNode, normal_form: str) -> list[dict[str, Any]]:
    if expr.op == "const" and expr.value is not None:
        focus_value = "1" if normal_form == "dnf" else "0"
        if ("1" if expr.value == "true" else "0") != focus_value:
            return []
        row_prefix = "T" if normal_form == "dnf" else "C"
        return [
            {
                "id": f"{row_prefix}1",
                "expression": _expr_to_pretty(expr),
                "spec": {},
            }
        ]
    return _extract_normal_form_groups(expr, normal_form)


def _extract_normal_form_groups(expr: ExprNode, normal_form: str) -> list[dict[str, Any]]:
    if normal_form == "cnf":
        outer_op = "and"
        inner_op = "or"
        row_prefix = "C"
    elif normal_form == "dnf":
        outer_op = "or"
        inner_op = "and"
        row_prefix = "T"
    else:
        raise ValueError(f"Unsupported normal form: {normal_form}")

    groups: list[dict[str, Any]] = []
    for index, group_expr in enumerate(_flatten_associative(expr, outer_op), start=1):
        literals = _flatten_associative(group_expr, inner_op)
        spec: dict[str, bool] = {}
        for literal in literals:
            variable, expected_value = _literal_constraint(literal, normal_form)
            if variable is None:
                continue
            spec[variable] = expected_value
        groups.append(
            {
                "id": f"{row_prefix}{index}",
                "expression": _expr_to_pretty(group_expr),
                "spec": spec,
            }
        )
    return groups


def _literal_constraint(literal: ExprNode, normal_form: str) -> tuple[str | None, bool]:
    if literal.op == "var" and literal.value is not None:
        return literal.value, normal_form == "dnf"
    if (
        literal.op == "not"
        and literal.left is not None
        and literal.left.op == "var"
        and literal.left.value is not None
    ):
        return literal.left.value, normal_form != "dnf"
    if literal.op == "const" and literal.value is not None:
        return None, literal.value == "true"
    raise ValueError(f"Unsupported literal in {normal_form.upper()} group: {literal!r}")


def _matches_group_spec(assignment: dict[str, bool], spec: dict[str, bool]) -> bool:
    return all(assignment.get(variable) == expected for variable, expected in spec.items())


def _group_rects_from_positions(
    positions: list[tuple[int, int]],
    row_count: int,
    col_count: int,
) -> list[dict[str, int]]:
    if not positions:
        return []

    rows = sorted({row for row, _ in positions})
    cols = sorted({col for _, col in positions})
    row_runs = _cyclic_index_runs(rows, row_count)
    col_runs = _cyclic_index_runs(cols, col_count)

    rects: list[dict[str, int]] = []
    for row_start, row_end in row_runs:
        for col_start, col_end in col_runs:
            rects.append(
                {
                    "row_start": row_start,
                    "row_end": row_end,
                    "col_start": col_start,
                    "col_end": col_end,
                }
            )
    return rects


def _cyclic_index_runs(indexes: list[int], size: int) -> list[tuple[int, int]]:
    if not indexes:
        return []
    if len(indexes) == size:
        return [(0, size - 1)]

    sorted_indexes = sorted(indexes)
    runs: list[list[int]] = [[sorted_indexes[0]]]
    for index in sorted_indexes[1:]:
        if index == runs[-1][-1] + 1:
            runs[-1].append(index)
        else:
            runs.append([index])

    return [(run[0], run[-1]) for run in runs]


def _op_label(op: str) -> str:
    return {
        "and": "&",
        "or": "|",
        "not": "~",
        "imp": "->",
        "iff": "<->",
        "var": "var",
        "const": "const",
    }.get(op, op)


def build_tree_dot(expr: ExprNode) -> str:
    lines = ["digraph FormulaTree {", '  rankdir=TB;', '  node [shape=box, style="rounded"];']
    counter = {"id": 0}

    def visit(node: ExprNode) -> str:
        node_id = f"n{counter['id']}"
        counter["id"] += 1

        if node.op == "var" and node.value is not None:
            label = node.value
        elif node.op == "const" and node.value is not None:
            label = node.value
        else:
            label = _op_label(node.op)
        lines.append(f'  {node_id} [label="{label}"];')

        if node.left is not None:
            left_id = visit(node.left)
            lines.append(f"  {node_id} -> {left_id};")
        if node.right is not None:
            right_id = visit(node.right)
            lines.append(f"  {node_id} -> {right_id};")
        return node_id

    visit(expr)
    lines.append("}")
    return "\n".join(lines)


def expr_to_string(expr: ExprNode) -> str:
    if expr.op == "const" and expr.value is not None:
        return expr.value
    if expr.op == "var" and expr.value is not None:
        return expr.value
    if expr.op == "not" and expr.left is not None:
        inner = expr_to_string(expr.left)
        if expr.left.op == "var":
            return f"~{inner}"
        return f"~({inner})"
    if expr.op in {"and", "or", "imp", "iff"} and expr.left is not None and expr.right is not None:
        op_text = {
            "and": "&",
            "or": "|",
            "imp": "->",
            "iff": "<->",
        }[expr.op]
        left = expr_to_string(expr.left)
        right = expr_to_string(expr.right)
        return f"({left} {op_text} {right})"
    raise ValueError("Invalid expression tree.")


def build_tree_steps(expr: ExprNode) -> list[str]:
    steps: list[str] = []
    counter = {"id": 0}

    def visit(node: ExprNode, parent_idx: int | None = None) -> None:
        counter["id"] += 1
        current_idx = counter["id"]
        expr_text = expr_to_string(node)
        if parent_idx is None:
            steps.append(f"{current_idx}. {expr_text}")
        else:
            steps.append(f"{current_idx}. {expr_text} ({parent_idx})")

        if node.left is not None:
            visit(node.left, current_idx)
        if node.right is not None:
            visit(node.right, current_idx)

    visit(expr)
    return steps


def count_nodes(expr: ExprNode) -> int:
    total = 1
    if expr.left is not None:
        total += count_nodes(expr.left)
    if expr.right is not None:
        total += count_nodes(expr.right)
    return total
