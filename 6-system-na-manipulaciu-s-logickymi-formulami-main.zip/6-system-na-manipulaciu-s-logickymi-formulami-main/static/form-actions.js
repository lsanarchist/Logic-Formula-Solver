(() => {
  const form = document.querySelector("form.workspace");
  const formulaInput = document.getElementById("formula");
  const formulaBInput = document.getElementById("formula_b");
  const randomButton = document.querySelector("[data-random-formula]");
  if (!form) return;

  function submitHiddenAction(action) {
    const hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = "action";
    hidden.value = action;
    form.append(hidden);

    if (form.requestSubmit) {
      form.requestSubmit();
    } else {
      form.submit();
    }
  }

  function submitWithButton(button) {
    if (button && form.requestSubmit) {
      form.requestSubmit(button);
      return;
    }

    if (button?.value) {
      submitHiddenAction(button.value);
      return;
    }

    form.submit();
  }

  randomButton?.addEventListener("click", () => {
    submitHiddenAction("random");
  });

  function handleFormulaEnter(event) {
    if (
      event.key !== "Enter"
      || event.shiftKey
      || event.ctrlKey
      || event.altKey
      || event.metaKey
    ) {
      return;
    }

    const shortcutPopup = document.getElementById("shortcut-popup");
    if (shortcutPopup?.classList.contains("visible")) return;

    event.preventDefault();
    const activeAction = form.querySelector(".tool-action.active");
    const analyzeAction = form.querySelector('.tool-action[value="analyze"]');
    const equivalenceAction = form.querySelector('.tool-action[value="equivalence"]');
    const fallbackAction = event.currentTarget === formulaBInput
      ? equivalenceAction
      : analyzeAction;
    submitWithButton(activeAction || fallbackAction || form.querySelector(".tool-action"));
  }

  formulaInput?.addEventListener("keydown", handleFormulaEnter);
  formulaBInput?.addEventListener("keydown", handleFormulaEnter);
})();
