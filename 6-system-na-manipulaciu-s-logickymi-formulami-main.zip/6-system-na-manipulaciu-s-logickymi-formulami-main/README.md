# 6 System Na Manipulaciu S Logickymi Formulami

## Run Web UI

1. Open a terminal in the project root.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Start the Flask app:

```bash
flask --app app run
```
or
```bash
python app.py
```
4. Open the local URL shown in terminal (usually `http://127.0.0.1:5000`).

For production-style local runs, use Gunicorn:

```bash
gunicorn app:app --bind 0.0.0.0:${PORT:-8080}
```

The main toolbar also includes a `Random Formula` button that fills the input with a parser-safe propositional formula using the same logical-symbol notation as the rest of the UI.


## Run Prolog Smoke Tests

Run the shared tracked PLUnit smoke suite from the project root:

```bash
swipl -q -g run_tests -t halt tests/prolog/smoke.plt
```

This suite now covers:
- propositional tokenization and parsing
- CNF, DNF, canonical CNF/DNF, Minimal CNF, and Minimal DNF
- Tseitin helper predicates
- predicate parsing
- prenex normal form conversion

## Current Scope

- The Flask UI in `app.py` works with propositional formulas and the Prolog transforms wired through `logic_backend.py`.
- Predicate parsing and prenex-normal-form support exist in Prolog and are covered by tests. Skolem/prenex output is exposed in the Flask UI through the existing Prolog predicates.

## Formula Input Shortcuts

The app now uses a notation table in the formula field. It shows the operator symbol, a LaTeX-style command, and accepted aliases. Type `/` or `\` to open the popup, then click an entry or use the arrow keys with `Enter`/`Tab`.

- `¬` with `\neg` and aliases `!`, `~`
- `∧` with `\land` and aliases `&`, `and`
- `∨` with `\lor` and aliases `|`, `or`
- `⇒` with `\Rightarrow` and aliases `→`, `⇒`, `->`
- `⇔` with `\Leftrightarrow` and aliases `⇔`, `<->`, `iff`
- `∀` with `\forall` and aliases `forall`, `ALL`
- `∃` with `\exists` and aliases `exists`, `EX`

Slash forms such as `/neg`, `/land`, `/lor`, `/forall`, `/exists`, `/leftrightarrow`, `/imp`, `/to`, and `/rightarrow` still work too, and all supported notations are normalized to logical symbols in the input field.

Examples:
- `/neg A /lor B` becomes `¬ A ∨ B`
- `A -> B` becomes `A ⇒ B`
- `A \Rightarrow B` becomes `A ⇒ B`
- `A and B` becomes `A ∧ B`
- `/forall x. P(x)` becomes `∀ x. P(x)`

## How `cnf_dnf_mimi.pl` Works

- `logic_backend.py` loads `cnf_dnf_mimi.pl` through `pyswip` (`consult(...)`), then calls Prolog predicates by name.
- CNF entry points:
  - `cnf_from_input/2` returns CNF AST.
  - `cnf_pretty_from_input/2` returns CNF in symbol form (pretty output).
- DNF entry points:
  - `dnf_from_input/2` returns DNF AST.
  - `dnf_pretty_from_input/2` returns DNF in symbol form.
- CNF pipeline (`to_cnf/2`):
  1. `eliminate_arrows/2` removes `->` and `<->`.
  2. `to_nnf/2` converts to NNF.
  3. `distribute_or_over_and/2` builds CNF.
- DNF pipeline (`to_dnf/2`):
  - `DNF(A) = NNF(not(CNF(not(A))))`
  - Implemented as: compute `to_cnf(not(A), C)`, then `to_nnf(not(C), DNF)`.

## How `canonical.pl` Works

- `canonical.pl` transforms CNF and DNF into **canonical form** where every variable appears in every clause (CNF) or term (DNF).
- Canonical CNF entry points:
  - `canonical_cnf_from_input/2` returns canonical CNF AST.
  - `canonical_cnf_pretty_from_input/2` returns canonical CNF in symbol form.
- Canonical DNF entry points:
  - `canonical_dnf_from_input/2` returns canonical DNF AST.
  - `canonical_dnf_pretty_from_input/2` returns canonical DNF in symbol form.
- Canonical CNF pipeline (`canonicalize_cnf/3`):
  1. Extract all variables from the formula.
  2. Convert CNF to a list of clauses.
  3. Normalize each clause (sort literals).
  4. Remove tautological clauses (e.g., `A | ~A`).
  5. **Expand clauses**: For missing variables, generate all $2^n$ combinations.
  6. Sort clauses and remove duplicates.
  7. Rebuild as CNF AST.
- Canonical DNF pipeline (`canonicalize_dnf/3`):
  1. Extract all variables from the formula.
  2. Convert DNF to a list of terms.
  3. Normalize each term (sort literals).
  4. Remove contradictory terms (e.g., `A & ~A`).
  5. **Expand terms**: For missing variables, generate all $2^n$ combinations.
  6. Sort terms and remove duplicates.
  7. Rebuild as DNF AST.
- Example: Formula `A & B & C` with clause `(A | B)` missing variable `C`:
  - Original: `(A | B)`
  - Expanded: `(A | B | C)` and `(A | B | ~C)`

## Minimal CNF And Minimal DNF

- `minimal.pl` now computes real Minimal CNF and Minimal DNF instead of forwarding to canonical forms.
- Minimal CNF starts from ordinary CNF, then removes tautological clauses, duplicate clauses, and clauses subsumed by stricter clauses.
- Minimal DNF starts from ordinary DNF, then removes contradictory terms, duplicate terms, and terms subsumed by broader terms.
- These minimal forms do not force canonical expansion, so they stay closer to the original formula shape when possible.
- In the Flask UI, `Minimal CNF` and `Minimal DNF` show both the final formula and a structured breakdown table of clauses/terms, literal counts, and variables.
- For formulas with up to 6 variables, the same result panels now also include an inline Karnaugh-style visualization section with color-coded groups derived from the minimal clauses or terms.

Examples:
- Minimal CNF of `A&(A|B)` is `A`
- Minimal CNF of `(A|B)&A` is `A`
- Minimal DNF of `A|(A&B)` is `A`
- Minimal DNF of `(A&B)|A` is `A`
