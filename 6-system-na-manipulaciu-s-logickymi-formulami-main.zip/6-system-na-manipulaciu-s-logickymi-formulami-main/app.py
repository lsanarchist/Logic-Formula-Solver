from __future__ import annotations

import re
from typing import Any

from flask import Flask, render_template, request
from markupsafe import Markup, escape

import logic_backend as backend

app = Flask(__name__)

_FORMULA_TOKEN_RE = re.compile(
    r"<->|->|=>|⇒|⇔|↔|→|[~¬!&∧|∨]|\(|\)|⊤|⊥|[A-Za-z_][A-Za-z0-9_]*"
)
_FORMULA_OPERATORS = {
    "<->",
    "->",
    "=>",
    "⇒",
    "⇔",
    "↔",
    "→",
    "~",
    "¬",
    "!",
    "&",
    "∧",
    "|",
    "∨",
}

PROPOSITIONAL_ACTIONS = [
    {"id": "analyze", "label": "Analyze"},
    {"id": "cnf", "label": "CNF"},
    {"id": "dnf", "label": "DNF"},
    {"id": "canonical_cnf", "label": "Canon. CNF"},
    {"id": "canonical_dnf", "label": "Canon. DNF"},
    {"id": "minimal_cnf", "label": "Minimal CNF"},
    {"id": "minimal_dnf", "label": "Minimal DNF"},
    {"id": "truth_table", "label": "Truth Table"},
    {"id": "equivalence", "label": "Equivalence"},
    {"id": "tree", "label": "Formula Tree"},
    {"id": "tseitin", "label": "Tseitin"},
]

PREDICATE_ACTIONS = [
    {"id": "predicate_tree", "label": "Formula Tree"},
    {"id": "prenex", "label": "Prenex form"},
    {"id": "skolem", "label": "Skolem form"},
]


@app.template_filter("formula_highlight")
def formula_highlight(value: object) -> Markup:
    text = "" if value is None else str(value)
    chunks: list[str] = []
    last = 0

    for match in _FORMULA_TOKEN_RE.finditer(text):
        if match.start() > last:
            chunks.append(str(escape(text[last : match.start()])))

        token = match.group(0)
        token_lower = token.lower()
        if token in _FORMULA_OPERATORS:
            css_class = "syntax-op"
        elif token in {"(", ")"}:
            css_class = "syntax-punct"
        elif token in {"⊤", "⊥"} or token_lower in {"true", "false"}:
            css_class = "syntax-const"
        else:
            css_class = "syntax-var"

        chunks.append(f'<span class="{css_class}">{escape(token)}</span>')
        last = match.end()

    if last < len(text):
        chunks.append(str(escape(text[last:])))

    return Markup("".join(chunks))


@app.route("/", methods=["GET", "POST"])
def index():
    predicate_example = backend.normalize_display_formula(
        "\\forall x. (P(x) -> \\exists y. Q(y))"
    )
    logic_mode = "propositional"
    if request.method == "POST":
        logic_mode = request.form.get("set_logic_mode") or request.form.get("logic_mode", "propositional")
    if logic_mode not in {"propositional", "predicate"}:
        logic_mode = "propositional"

    default_formula = (
        predicate_example
        if logic_mode == "predicate"
        else "A->B"
    )
    formula = request.form.get("formula", default_formula) if request.method == "POST" else default_formula
    formula_b = request.form.get("formula_b", "~A | B") if request.method == "POST" else "~A | B"
    result: dict[str, Any] | None = None
    error: str | None = None
    active_action = request.form.get("action") if request.method == "POST" else None
    actions = PREDICATE_ACTIONS if logic_mode == "predicate" else PROPOSITIONAL_ACTIONS

    if request.method == "POST":
        if request.form.get("set_logic_mode"):
            active_action = None
            formula = default_formula
        elif active_action == "random" and logic_mode == "propositional":
            formula = backend.generate_random_formula()
            active_action = None
        else:
            formula = backend.normalize_display_formula(formula)
            formula_b = backend.normalize_display_formula(formula_b)
            try:
                result = build_result(active_action, formula, formula_b, logic_mode)
            except Exception as exc:
                error = str(exc)

    return render_template(
        "index.html",
        actions=actions,
        active_action=active_action,
        error=error,
        formula=formula,
        formula_b=formula_b,
        logic_mode=logic_mode,
        predicate_example=predicate_example,
        result=result,
        shortcuts=backend.shortcut_suggestions(),
    )


def build_result(action: str | None, formula: str, formula_b: str | None = None, logic_mode: str = "propositional") -> dict[str, Any] | None:
    allowed_actions = {
        action_spec["id"]
        for action_spec in (
            PREDICATE_ACTIONS if logic_mode == "predicate" else PROPOSITIONAL_ACTIONS
        )
    }
    if action is not None and action not in allowed_actions:
        raise ValueError("This action is not available in the selected logic mode.")


    if action == "analyze":
        tokens_text, ast_text = backend.analyze_formula(formula)
        return {
            "kind": "sections",
            "title": "Analysis",
            "sections": [
                {"title": "Tokens", "body": tokens_text},
                {"title": "AST", "body": ast_text},
            ],
        }

    if action == "cnf":
        return _formula_result("CNF Result", backend.cnf_formula(formula))

    if action == "dnf":
        return _formula_result("DNF Result", backend.dnf_formula(formula))

    if action == "canonical_cnf":
        return _formula_result("Canonical CNF Result", backend.canonical_cnf_formula(formula))

    if action == "canonical_dnf":
        return _formula_result("Canonical DNF Result", backend.canonical_dnf_formula(formula))

    if action == "minimal_cnf":
        formula_text = backend.minimal_cnf_formula(formula)
        details = backend.normal_form_details(formula_text, "cnf", source_formula=formula)
        return {
            "kind": "normal_form",
            "title": "Minimal CNF Result",
            "formula": formula_text,
            "normal_form": "cnf",
            **details,
        }

    if action == "minimal_dnf":
        formula_text = backend.minimal_dnf_formula(formula)
        details = backend.normal_form_details(formula_text, "dnf", source_formula=formula)
        return {
            "kind": "normal_form",
            "title": "Minimal DNF Result",
            "formula": formula_text,
            "normal_form": "dnf",
            **details,
        }

    if action == "truth_table":
        rows, mdnf_text, mcnf_text, props = backend.truth_table_bundle(formula)
        return {
            "kind": "truth_table",
            "title": "Truth Table",
            "rows": rows,
            "columns": list(rows[0].keys()) if rows else [],
            "mdnf": mdnf_text,
            "mcnf": mcnf_text,
            "props": props,
        }

    if action == "equivalence":
        second_formula = formula_b or ""
        report = backend.logical_equivalence_report(formula, second_formula)
        return {
            "kind": "equivalence",
            "title": "Logical Equivalence",
            "formula_a": formula,
            "formula_b": second_formula,
            **report,
        }

    if action == "tree":
        return {
            "kind": "tree",
            "title": "Formula Tree",
            "tree": backend.formula_tree(formula),
            "legend_variant": "formula",
            "node_info": {},
            "show_info_panel": False,
        }

    if action == "predicate_tree":
        return {
            "kind": "tree",
            "title": "Predicate Formula Tree",
            "tree": backend.predicate_formula_tree(formula),
            "legend_variant": "formula",
            "node_info": {},
            "show_info_panel": False,
        }

    if action == "prenex":
        return _formula_result("Prenex Form", backend.prenex_formula(formula))

    if action == "tseitin":
        tree, full_formula, node_info = backend.tseitin_transform(formula)
        return {
            "kind": "tseitin",
            "title": "Tseitin Transformation",
            "formula": full_formula,
            "clauses": _split_top_level_conjunction(full_formula),
            "tree": tree,
            "legend_variant": "tseitin",
            "node_info": node_info,
            "show_info_panel": True,
        }

    if action == "skolem":
        prenex_text, skolem_text = backend.skolem_steps_pretty(formula)
        result = {
            "kind": "sections",
            "title": "Skolem Normal Form",
            "sections": [
                {"title": "Prenex", "body": prenex_text},
                {"title": "Skolem", "body": skolem_text},
            ],
            "notices": [],
        }
        if not backend.predicate_formula_has_quantifiers(formula):
            result["notices"].append(
                "This formula does not contain quantifiers, so Skolem normal form is trivial here."
            )
        return result

    return None


def _formula_result(title: str, value: str) -> dict[str, Any]:
    return {
        "kind": "formula",
        "title": title,
        "formula": value,
    }


def _split_top_level_conjunction(formula: str) -> list[str]:
    parts: list[str] = []
    depth = 0
    start = 0

    for index, char in enumerate(formula):
        if char == "(":
            depth += 1
        elif char == ")":
            depth = max(0, depth - 1)
        elif depth == 0 and char in {"&", "∧"}:
            part = formula[start:index].strip()
            if part:
                parts.append(part)
            start = index + 1

    tail = formula[start:].strip()
    if tail:
        parts.append(tail)
    return parts or [formula]


if __name__ == "__main__":
    app.run(debug=True)
