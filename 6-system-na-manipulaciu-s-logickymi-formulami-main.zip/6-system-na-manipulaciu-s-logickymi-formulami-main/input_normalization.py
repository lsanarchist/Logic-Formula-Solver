import re


SHORTCUT_SUGGESTION_ROWS = (
    {
        "symbol": "⇒",
        "command": "\\Rightarrow",
        "aliases": ["→", "⇒", "->"],
        "kind": "connective",
        "triggers": ["/imp", "/to", "/implies", "/rightarrow", "\\Rightarrow"],
    },
    {
        "symbol": "⇔",
        "command": "\\Leftrightarrow",
        "aliases": ["⇔", "<->", "iff"],
        "kind": "connective",
        "triggers": ["/iff", "/equiv", "/leftrightarrow", "\\Leftrightarrow"],
    },
    {
        "symbol": "∨",
        "command": "\\lor",
        "aliases": ["|", "or"],
        "kind": "connective",
        "triggers": ["/lor", "/vee", "\\lor"],
    },
    {
        "symbol": "∧",
        "command": "\\land",
        "aliases": ["&", "and"],
        "kind": "connective",
        "triggers": ["/land", "/wedge", "\\land"],
    },
    {
        "symbol": "¬",
        "command": "\\neg",
        "aliases": ["!", "~"],
        "kind": "negation",
        "triggers": ["/neg", "/not", "\\neg"],
    },
    {
        "symbol": "∀",
        "command": "\\forall",
        "aliases": ["forall", "ALL"],
        "kind": "quantifier",
        "triggers": ["/forall", "\\forall"],
    },
    {
        "symbol": "∃",
        "command": "\\exists",
        "aliases": ["exists", "EX"],
        "kind": "quantifier",
        "triggers": ["/exists", "\\exists"],
    },
    {
        "symbol": "⊤",
        "command": "\\top",
        "aliases": ["true", "verum"],
        "kind": "constant",
        "triggers": ["/top", "\\top", "/verum", "\\verum"],
    },
    {
        "symbol": "⊥",
        "command": "\\bot",
        "aliases": ["false", "absurdum"],
        "kind": "constant",
        "triggers": ["/bot", "\\bot", "/absurdum", "\\absurdum"],
    },
)


SHORTCUT_REPLACEMENTS = {
    "leftrightarrow": "⇔",
    "rightarrow": "⇒",
    "implies": "⇒",
    "forall": "∀",
    "exists": "∃",
    "equiv": "⇔",
    "wedge": "∧",
    "lnot": "¬",
    "land": "∧",
    "lor": "∨",
    "neg": "¬",
    "not": "¬",
    "iff": "⇔",
    "imp": "⇒",
    "vee": "∨",
    "to": "⇒",
    "top": "⊤",
    "bot": "⊥",
    "verum": "⊤",
    "absurdum": "⊥",
}

WORD_ALIAS_REPLACEMENTS = {
    "forall": "∀",
    "exists": "∃",
    "and": "∧",
    "or": "∨",
}

UPPERCASE_ALIAS_REPLACEMENTS = {
    "ALL": "∀",
    "EX": "∃",
}

OPERATOR_ALIAS_REPLACEMENTS = {
    "<->": "⇔",
    "->": "⇒",
    "→": "⇒",
    "⇒": "⇒",
    "⇔": "⇔",
    "|": "∨",
    "&": "∧",
    "~": "¬",
}

PROLOG_OPERATOR_REPLACEMENTS = {
    "¬": "~",
    "∧": "&",
    "∨": "|",
    "⇒": "->",
    "⇔": "<->",
    "∀": "forall",
    "∃": "exists",
    "⊤": "true",
    "⊥": "false",
}

_COMMAND_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])(?P<prefix>[\\\\/])(?P<command>"
    + "|".join(re.escape(name) for name in sorted(SHORTCUT_REPLACEMENTS, key=len, reverse=True))
    + r")(?![A-Za-z0-9_])",
    flags=re.IGNORECASE,
)

_WORD_ALIAS_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])(?P<token>"
    + "|".join(re.escape(name) for name in sorted(WORD_ALIAS_REPLACEMENTS, key=len, reverse=True))
    + r")(?![A-Za-z0-9_])",
    flags=re.IGNORECASE,
)

_UPPERCASE_ALIAS_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])(?P<token>"
    + "|".join(re.escape(name) for name in sorted(UPPERCASE_ALIAS_REPLACEMENTS, key=len, reverse=True))
    + r")(?![A-Za-z0-9_])"
)

_OPERATOR_ALIAS_PATTERN = re.compile(
    r"<->|->|→|⇒|⇔|\||&|~|!(?!=)"
)


def normalize_formula_input(formula: str) -> str:
    """Normalize slash and LaTeX-like shortcut commands into logical symbols."""
    if not formula:
        return formula

    normalized = _COMMAND_PATTERN.sub(_replace_shortcut, formula)
    normalized = _WORD_ALIAS_PATTERN.sub(_replace_word_alias, normalized)
    normalized = _UPPERCASE_ALIAS_PATTERN.sub(_replace_uppercase_alias, normalized)
    return _OPERATOR_ALIAS_PATTERN.sub(_replace_operator_alias, normalized)


def normalize_formula_for_prolog(formula: str) -> str:
    """Return a tokenizer-friendly ASCII form for the Prolog backend."""
    normalized = normalize_formula_input(formula)
    for symbol, replacement in PROLOG_OPERATOR_REPLACEMENTS.items():
        normalized = normalized.replace(symbol, replacement)
    return normalized


def get_shortcut_suggestions() -> list[dict[str, object]]:
    """Return UI-facing shortcut metadata for autocomplete and docs."""
    return [dict(row) for row in SHORTCUT_SUGGESTION_ROWS]


def _replace_shortcut(match: re.Match[str]) -> str:
    command = match.group("command").lower()
    return SHORTCUT_REPLACEMENTS.get(command, match.group(0))


def _replace_word_alias(match: re.Match[str]) -> str:
    token = match.group("token").lower()
    return WORD_ALIAS_REPLACEMENTS.get(token, match.group(0))


def _replace_uppercase_alias(match: re.Match[str]) -> str:
    token = match.group("token")
    return UPPERCASE_ALIAS_REPLACEMENTS.get(token, match.group(0))


def _replace_operator_alias(match: re.Match[str]) -> str:
    token = match.group(0)
    if token == "!":
        return "¬"
    return OPERATOR_ALIAS_REPLACEMENTS.get(token, token)
