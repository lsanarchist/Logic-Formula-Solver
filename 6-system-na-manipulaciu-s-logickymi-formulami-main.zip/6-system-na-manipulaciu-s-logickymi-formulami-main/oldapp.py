import ast
import json
import re
from pathlib import Path
import random

import streamlit as st
from pyswip import Prolog
from formula_frontend import (
    build_karnaugh_map,
    build_normal_form_table,
    build_tree_dot,
    build_tree_steps,
    prolog_ast_to_exprnode,
)
from input_normalization import (
    get_shortcut_suggestions,
    normalize_formula_for_prolog,
    normalize_formula_input,
)

PROJECT_ROOT = Path(__file__).resolve().parent
PARSER_FILE = PROJECT_ROOT / "parser_propositional.pl"
CNF_DNF_FILE = PROJECT_ROOT / "cnf_dnf_mimi.pl"
CANONICAL_FILE = PROJECT_ROOT / "canonical.pl"
MINIMAL_FILE = PROJECT_ROOT / "minimal.pl"
TRUTH_TABLE_FILE = PROJECT_ROOT / "truth_table.pl"
TSEITIN_FILE = PROJECT_ROOT / "tseitin.pl"
SKOLEM_FILE = PROJECT_ROOT / "skolem.pl"

def _to_prolog_atom(text: str) -> str:
    escaped = text.replace("\\", "\\\\").replace("'", "''")
    return f"'{escaped}'"


def _prepare_formula_input(formula: str) -> str:
    normalized = normalize_formula_for_prolog(formula).strip()
    if not normalized:
        raise ValueError("Formula cannot be empty.")
    return normalized


_QUANTIFIER_TOKEN_RE = re.compile(
    r"\bforall\b|\bexists\b|∀|∃",
    flags=re.IGNORECASE,
)


def _predicate_formula_has_quantifiers(formula: str) -> bool:
    """True if text mentions predicate quantifiers (after UI shortcut normalization)."""
    if not formula or not formula.strip():
        return False
    return bool(_QUANTIFIER_TOKEN_RE.search(normalize_formula_input(formula)))


def _normalize_formula_widget() -> None:
    if "formula" not in st.session_state:
        return
    st.session_state["formula"] = normalize_formula_input(st.session_state["formula"])


def _set_random_formula() -> None:
    st.session_state["formula"] = _generate_random_formula()


def _generate_random_formula() -> str:
    variables = random.sample(["A", "B", "C", "D", "E", "F"], k=random.randint(2, 4))
    expr = _random_formula_expr(depth=random.randint(2, 4), variables=variables, force_binary=True)
    return _random_formula_to_text(expr)


def _random_formula_expr(
    depth: int,
    variables: list[str],
    force_binary: bool = False,
):
    if depth <= 0:
        return random.choice(variables)

    if not force_binary and random.random() < 0.30:
        return random.choice(variables)

    if not force_binary and random.random() < 0.24:
        return ("not", _random_formula_expr(depth - 1, variables))

    operator = random.choices(
        ["and", "or", "imp", "iff"],
        weights=[4, 4, 2, 1],
        k=1,
    )[0]
    left = _random_formula_expr(depth - 1, variables)
    right = _random_formula_expr(depth - 1, variables)

    if left == right and operator in {"imp", "iff"} and len(variables) > 1:
        alternatives = [var for var in variables if var != left]
        if alternatives:
            right = random.choice(alternatives)

    return (operator, left, right)


def _random_formula_to_text(expr) -> str:
    if isinstance(expr, str):
        return expr
    elif isinstance(expr, tuple) and len(expr) == 2 and expr[0] == "not":
        child = expr[1]
        child_text = _random_formula_to_text(child)
        if isinstance(child, tuple) and len(child) == 3:
            return f"¬({child_text})"
        return f"¬{child_text}"
    elif isinstance(expr, tuple) and len(expr) == 3:
        op, left, right = expr
        symbol = {
            "and": " ∧ ",
            "or": " ∨ ",
            "imp": " ⇒ ",
            "iff": " ⇔ ",
        }[op]
        left_text = _random_formula_to_text(left)
        right_text = _random_formula_to_text(right)
        return f"({left_text}{symbol}{right_text})"
    else:
        raise ValueError("Unexpected random formula expression.")


def _render_normal_form_result(
    title: str,
    formula_text: str,
    normal_form: str,
    source_formula: str | None = None,
) -> None:
    st.subheader(f"{title} Result")
    st.code(formula_text)

    try:
        rows, summary = build_normal_form_table(
            formula_text,
            parse_expr=parse_formula_expr,
            normal_form=normal_form,
            source_formula=source_formula,
        )
    except Exception as exc:
        st.warning(f"Structured {title.lower()} table is unavailable: {exc}")
    else:
        st.markdown("#### Structure")
        label = str(summary["row_label"])
        summary_col1, summary_col2, summary_col3, summary_col4 = st.columns(4)
        with summary_col1:
            st.metric(label, int(summary["group_count"]))
        with summary_col2:
            st.metric("Literals", int(summary["literal_count"]))
        with summary_col3:
            st.metric("Variables", int(summary["variable_count"]))
        with summary_col4:
            st.metric("Join", str(summary["join_symbol"]))

        st.caption(f"Variables: {summary['variables']}")
        st.dataframe(rows, use_container_width=True, hide_index=True)

    try:
        map_data = build_karnaugh_map(
            formula_text,
            parse_expr=parse_formula_expr,
            normal_form=normal_form,
            source_formula=source_formula,
        )
    except Exception as exc:
        st.info(f"Karnaugh map is unavailable for this result: {exc}")
    else:
        st.markdown("#### Karnaugh Map")
        st.caption(
            f"{title} groups highlight value {map_data['focus_value']} across Gray-code ordered rows and columns."
        )
        st.components.v1.html(
            _build_karnaugh_map_html(title, map_data),
            height=_karnaugh_map_height(map_data),
            scrolling=False,
        )


def _karnaugh_map_height(map_data: dict) -> int:
    row_count = int(map_data["rows"])
    group_count = len(map_data["groups"])
    legend_rows = (group_count + 2) // 3
    grid_height = (row_count + 1) * 78 + 20
    return max(560, min(1200, 300 + grid_height + legend_rows * 42))


def _build_karnaugh_map_html(title: str, map_data: dict) -> str:
    map_json = json.dumps(map_data, ensure_ascii=False)
    title_json = json.dumps(title, ensure_ascii=False)
    return rf"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0;
    padding: 12px;
    font-family: "JetBrains Mono", "Fira Code", Consolas, monospace;
    background: transparent;
    color: var(--kmap-text);
  }}
  #kmap-root {{
    border: 1px solid var(--kmap-border);
    border-radius: 18px;
    background:
      linear-gradient(180deg, var(--kmap-panel-top), var(--kmap-panel-bottom));
    box-shadow:
      0 18px 38px var(--kmap-shadow),
      inset 0 0 0 1px var(--kmap-glow);
    padding: 18px;
  }}
  .kmap-header {{
    display: flex;
    justify-content: space-between;
    gap: 16px;
    align-items: flex-start;
    flex-wrap: wrap;
    margin-bottom: 14px;
  }}
  .kmap-title {{
    font-size: 18px;
    font-weight: 800;
    color: var(--kmap-title);
    margin-bottom: 6px;
  }}
  .kmap-subtitle {{
    color: var(--kmap-muted);
    font-size: 12px;
    line-height: 1.45;
  }}
  .kmap-legend {{
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: flex-end;
    max-width: min(52%, 100%);
  }}
  .kmap-chip {{
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 10px;
    border-radius: 999px;
    border: 1px solid var(--kmap-chip-border);
    background: var(--kmap-chip-bg);
    color: var(--kmap-text);
    font-size: 12px;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04);
  }}
  .kmap-chip-swatch {{
    width: 10px;
    height: 10px;
    border-radius: 999px;
    flex: 0 0 auto;
  }}
  .kmap-layout {{
    display: grid;
    grid-template-columns: 110px minmax(0, 1fr);
    gap: 14px;
    align-items: start;
  }}
  .kmap-side-note {{
    display: flex;
    flex-direction: column;
    gap: 8px;
    color: var(--kmap-muted);
    font-size: 12px;
    line-height: 1.45;
    padding-top: 52px;
  }}
  .kmap-grid-wrap {{
    overflow-x: auto;
    justify-self: start;
    width: fit-content;
    max-width: 100%;
    padding: 8px;
    border: 1px solid var(--kmap-border);
    border-radius: 22px;
    background:
      radial-gradient(circle at top, var(--kmap-grid-sheen), transparent 58%),
      linear-gradient(180deg, var(--kmap-grid-top), var(--kmap-grid-bottom));
    box-shadow:
      inset 0 0 0 1px var(--kmap-glow),
      0 10px 24px rgba(2, 6, 23, 0.08);
  }}
  .kmap-grid {{
    display: grid;
    gap: 0;
    width: max-content;
    position: relative;
    isolation: isolate;
    border-radius: 16px;
    overflow: hidden;
  }}
  .kmap-corner,
  .kmap-col-head,
  .kmap-row-head,
  .kmap-cell {{
    min-width: 78px;
    min-height: 78px;
  }}
  .kmap-corner {{
    position: relative;
    z-index: 5;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 8px;
    padding: 10px 12px;
    border: 1px solid var(--kmap-grid-line);
    background: var(--kmap-header-bg);
    color: var(--kmap-muted);
  }}
  .kmap-axis-label {{
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }}
  .kmap-axis-vars {{
    color: var(--kmap-title);
    font-size: 14px;
    font-weight: 700;
  }}
  .kmap-col-head,
  .kmap-row-head {{
    position: relative;
    z-index: 5;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--kmap-grid-line);
    background: var(--kmap-header-bg);
    color: var(--kmap-title);
    font-size: 14px;
    font-weight: 700;
  }}
  .kmap-cell {{
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--kmap-grid-line);
    background:
      linear-gradient(180deg, var(--kmap-cell-top), var(--kmap-cell-bg));
    color: var(--kmap-title);
    font-size: 28px;
    font-weight: 800;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.025);
  }}
  .kmap-cell[data-value="1"] {{
    background:
      radial-gradient(circle at top, var(--kmap-hotspot), transparent 62%),
      linear-gradient(180deg, var(--kmap-cell-top), var(--kmap-cell-bg));
  }}
  .kmap-cell[data-value="0"] {{
    color: var(--kmap-zero);
  }}
  .kmap-cell-value {{
    position: relative;
    z-index: 3;
    text-shadow: 0 4px 18px var(--kmap-cell-value-glow);
  }}
  .kmap-index {{
    position: absolute;
    left: 8px;
    bottom: 6px;
    font-size: 11px;
    color: var(--kmap-muted);
    font-weight: 600;
    z-index: 3;
  }}
  .kmap-group-fill-stage,
  .kmap-group-line-stage {{
    position: absolute;
    pointer-events: none;
    overflow: visible;
  }}
  .kmap-group-fill-stage {{
    z-index: 2;
  }}
  .kmap-group-line-stage {{
    z-index: 4;
  }}
  .kmap-foot {{
    margin-top: 12px;
    color: var(--kmap-muted);
    font-size: 12px;
    line-height: 1.5;
  }}
  @media (max-width: 720px) {{
    body {{
      padding: 8px;
    }}
    #kmap-root {{
      padding: 14px;
      border-radius: 14px;
    }}
    .kmap-header {{
      display: block;
    }}
    .kmap-legend {{
      justify-content: flex-start;
      max-width: 100%;
      margin-top: 12px;
    }}
    .kmap-layout {{
      grid-template-columns: 1fr;
    }}
    .kmap-side-note {{
      padding-top: 0;
    }}
  }}
</style>
</head>
<body>
<div id="kmap-root"></div>
<script>
const TITLE = {title_json};
const DATA = {map_json};
const DARK = {{
  text:"#e2e8f0",
  title:"#f8fafc",
  muted:"#94a3b8",
  border:"#334155",
  border_soft:"#1e293b",
  panel_top:"rgba(13, 17, 23, 0.98)",
  panel_bottom:"rgba(15, 23, 42, 0.98)",
  shadow:"rgba(2, 6, 23, 0.45)",
  glow:"rgba(56, 189, 248, 0.08)",
  chip_bg:"rgba(15, 23, 42, 0.8)",
  chip_border:"#334155",
  header_bg:"rgba(15, 23, 42, 0.72)",
  grid_top:"rgba(9, 15, 29, 0.98)",
  grid_bottom:"rgba(7, 12, 24, 0.98)",
  grid_sheen:"rgba(56, 189, 248, 0.12)",
  grid_line:"rgba(71, 85, 105, 0.72)",
  cell_top:"rgba(17, 24, 39, 0.98)",
  cell_bg:"rgba(2, 6, 23, 0.98)",
  cell_value_glow:"rgba(148, 163, 184, 0.14)",
  hotspot:"rgba(56, 189, 248, 0.05)",
  zero:"#94a3b8",
}};
const LIGHT = {{
  text:"#111827",
  title:"#0f172a",
  muted:"#6b7280",
  border:"#d1d5db",
  border_soft:"#e5e7eb",
  panel_top:"rgba(255, 255, 255, 0.98)",
  panel_bottom:"rgba(248, 250, 252, 0.98)",
  shadow:"rgba(15, 23, 42, 0.10)",
  glow:"rgba(21, 128, 61, 0.04)",
  chip_bg:"rgba(249, 250, 251, 0.95)",
  chip_border:"#d1d5db",
  header_bg:"rgba(248, 250, 252, 0.92)",
  grid_top:"rgba(255, 255, 255, 0.98)",
  grid_bottom:"rgba(248, 250, 252, 0.98)",
  grid_sheen:"rgba(22, 163, 74, 0.07)",
  grid_line:"rgba(148, 163, 184, 0.62)",
  cell_top:"rgba(255, 255, 255, 0.98)",
  cell_bg:"rgba(248, 250, 252, 0.98)",
  cell_value_glow:"rgba(15, 23, 42, 0.10)",
  hotspot:"rgba(22, 163, 74, 0.04)",
  zero:"#6b7280",
}};

function parseRgb(rgb) {{
  if (!rgb) return null;
  const match = String(rgb).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!match) return null;
  return [Number(match[1]), Number(match[2]), Number(match[3])];
}}

function luminance(rgb) {{
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}}

function detectTheme() {{
  try {{
    const pDoc = window.parent.document;
    const root = pDoc.documentElement;
    const body = pDoc.body;
    const attrs = [
      root?.getAttribute("data-theme"),
      body?.getAttribute("data-theme"),
      root?.dataset?.theme,
      body?.dataset?.theme,
      root?.className,
      body?.className,
    ].filter(Boolean).join(" ").toLowerCase();
    if (attrs.includes("dark")) return "dark";
    if (attrs.includes("light")) return "light";
    const rgb = parseRgb(window.parent.getComputedStyle(body).backgroundColor)
      || parseRgb(window.parent.getComputedStyle(root).backgroundColor);
    if (rgb) return luminance(rgb) < 140 ? "dark" : "light";
  }} catch (error) {{
    // ignore
  }}
  return "dark";
}}

function applyTheme(colors) {{
  const root = document.documentElement;
  Object.entries(colors).forEach(([key, value]) => {{
    root.style.setProperty(`--kmap-${{key.replaceAll("_", "-")}}`, value);
  }});
}}

function hexToRgb(hex) {{
  if (!hex) return null;
  const value = String(hex).trim().replace(/^#/, "");
  if (![3, 6].includes(value.length)) return null;
  const normalized = value.length === 3
    ? value.split("").map((char) => char + char).join("")
    : value;
  const parsed = Number.parseInt(normalized, 16);
  if (Number.isNaN(parsed)) return null;
  return [
    (parsed >> 16) & 255,
    (parsed >> 8) & 255,
    parsed & 255,
  ];
}}

function withAlpha(hex, alpha) {{
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  return `rgba(${{rgb[0]}}, ${{rgb[1]}}, ${{rgb[2]}}, ${{alpha}})`;
}}

function mixHex(base, target, ratio) {{
  const a = hexToRgb(base);
  const b = hexToRgb(target);
  if (!a || !b) return base;
  const mixed = a.map((value, index) =>
    Math.round(value + (b[index] - value) * ratio)
  );
  return `rgb(${{mixed[0]}}, ${{mixed[1]}}, ${{mixed[2]}})`;
}}

function syncGroupStages(grid, fillStage, lineStage) {{
  const firstCell = grid.querySelector('.kmap-cell[data-row="0"][data-col="0"]');
  const lastCell = grid.querySelector(`.kmap-cell[data-row="${{DATA.rows - 1}}"][data-col="${{DATA.cols - 1}}"]`);
  if (!firstCell || !lastCell) return null;

  const gridRect = grid.getBoundingClientRect();
  const firstRect = firstCell.getBoundingClientRect();
  const lastRect = lastCell.getBoundingClientRect();
  const dataLeft = firstRect.left - gridRect.left;
  const dataTop = firstRect.top - gridRect.top;
  const dataWidth = lastRect.right - firstRect.left;
  const dataHeight = lastRect.bottom - firstRect.top;

  for (const stage of [fillStage, lineStage]) {{
    stage.setAttribute("width", String(dataWidth));
    stage.setAttribute("height", String(dataHeight));
    stage.setAttribute("viewBox", `0 0 ${{dataWidth}} ${{dataHeight}}`);
    stage.style.left = `${{dataLeft}}px`;
    stage.style.top = `${{dataTop}}px`;
    stage.style.width = `${{dataWidth}}px`;
    stage.style.height = `${{dataHeight}}px`;
  }}

  const colStarts = [];
  const colEnds = [];
  const rowStarts = [];
  const rowEnds = [];
  for (let colIndex = 0; colIndex < DATA.cols; colIndex += 1) {{
    const cell = grid.querySelector(`.kmap-cell[data-row="0"][data-col="${{colIndex}}"]`);
    const rect = cell.getBoundingClientRect();
    colStarts.push(rect.left - firstRect.left);
    colEnds.push(rect.right - firstRect.left);
  }}
  for (let rowIndex = 0; rowIndex < DATA.rows; rowIndex += 1) {{
    const cell = grid.querySelector(`.kmap-cell[data-row="${{rowIndex}}"][data-col="0"]`);
    const rect = cell.getBoundingClientRect();
    rowStarts.push(rect.top - firstRect.top);
    rowEnds.push(rect.bottom - firstRect.top);
  }}

  return {{ colStarts, colEnds, rowStarts, rowEnds }};
}}

function render() {{
  const isLight = detectTheme() === "light";
  const theme = isLight ? LIGHT : DARK;
  applyTheme(theme);
  const root = document.getElementById("kmap-root");
  const CELL_SIZE = 78;
  const columnCount = DATA.cols + 1;
  root.innerHTML = "";

  const header = document.createElement("div");
  header.className = "kmap-header";
  header.innerHTML = `
    <div>
      <div class="kmap-title">${{TITLE}}</div>
      <div class="kmap-subtitle">
        Columns: ${{DATA.col_vars.length ? DATA.col_vars.join(", ") : "—"}}<br/>
        Rows: ${{DATA.row_vars.length ? DATA.row_vars.join(", ") : "—"}}
      </div>
    </div>
    <div class="kmap-legend">
      ${{
        DATA.groups.map((group) => `
          <div
            class="kmap-chip"
            style="
              border-color:${{withAlpha(group.color, isLight ? 0.32 : 0.46)}};
              background:${{withAlpha(group.color, isLight ? 0.07 : 0.11)}};
            "
          >
            <span
              class="kmap-chip-swatch"
              style="
                background:${{group.color}};
                box-shadow:
                  0 0 0 4px ${{withAlpha(group.color, isLight ? 0.10 : 0.18)}},
                  0 0 20px ${{withAlpha(group.color, isLight ? 0.16 : 0.26)}};
              "
            ></span>
            <strong>${{group.id}}</strong>
            <span>${{group.expression}}</span>
          </div>
        `).join("")
      }}
    </div>
  `;
  root.appendChild(header);

  const layout = document.createElement("div");
  layout.className = "kmap-layout";
  root.appendChild(layout);

  const side = document.createElement("div");
  side.className = "kmap-side-note";
  side.innerHTML = `
    <div>Focus value: <strong>${{DATA.focus_value}}</strong></div>
    <div>Gray-code columns: ${{DATA.col_labels.join(", ")}}</div>
    <div>Gray-code rows: ${{DATA.row_labels.join(", ")}}</div>
  `;
  layout.appendChild(side);

  const wrap = document.createElement("div");
  wrap.className = "kmap-grid-wrap";
  layout.appendChild(wrap);

  const grid = document.createElement("div");
  grid.className = "kmap-grid";
  grid.style.gridTemplateColumns = `repeat(${{columnCount}}, minmax(${{CELL_SIZE}}px, ${{CELL_SIZE}}px))`;
  wrap.appendChild(grid);

  const corner = document.createElement("div");
  corner.className = "kmap-corner";
  corner.innerHTML = `
    <div>
      <div class="kmap-axis-label">Cols</div>
      <div class="kmap-axis-vars">${{DATA.col_vars.length ? DATA.col_vars.join(", ") : "—"}}</div>
    </div>
    <div>
      <div class="kmap-axis-label">Rows</div>
      <div class="kmap-axis-vars">${{DATA.row_vars.length ? DATA.row_vars.join(", ") : "—"}}</div>
    </div>
  `;
  grid.appendChild(corner);

  DATA.col_labels.forEach((label) => {{
    const head = document.createElement("div");
    head.className = "kmap-col-head";
    head.textContent = label;
    grid.appendChild(head);
  }});

  for (let rowIndex = 0; rowIndex < DATA.rows; rowIndex += 1) {{
    const rowHead = document.createElement("div");
    rowHead.className = "kmap-row-head";
    rowHead.textContent = DATA.row_labels[rowIndex];
    grid.appendChild(rowHead);

    for (let colIndex = 0; colIndex < DATA.cols; colIndex += 1) {{
      const cell = DATA.cells.find((item) => item.row === rowIndex && item.col === colIndex);
      const cellEl = document.createElement("div");
      cellEl.className = "kmap-cell";
      cellEl.dataset.value = cell.value;
      cellEl.dataset.row = String(rowIndex);
      cellEl.dataset.col = String(colIndex);
      cellEl.innerHTML = `
        <span class="kmap-cell-value">${{cell.value}}</span>
        <span class="kmap-index">${{cell.index}}</span>
      `;

      grid.appendChild(cellEl);
    }}
  }}

  const fillStage = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  fillStage.classList.add("kmap-group-fill-stage");
  grid.appendChild(fillStage);

  const lineStage = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  lineStage.classList.add("kmap-group-line-stage");
  grid.appendChild(lineStage);

  const metrics = syncGroupStages(grid, fillStage, lineStage);
  if (!metrics) return;

  DATA.groups.forEach((group, groupIndex) => {{
    const lane = groupIndex % 3;
    const inset = 4 + lane * 2.5;
    const radius = 18 - lane;
    const haloWidth = 10 - lane * 1.2;
    const strokeWidth = 3.2;
    const fillColor = withAlpha(group.color, isLight ? 0.08 : 0.12);
    const glowColor = withAlpha(group.color, isLight ? 0.18 : 0.28);
    const haloColor = withAlpha(group.color, isLight ? 0.42 : 0.52);
    const crispStroke = mixHex(group.color, isLight ? "#ffffff" : "#f8fafc", isLight ? 0.16 : 0.10);
    for (const rect of group.rects || []) {{
      const x = metrics.colStarts[rect.col_start] + inset;
      const y = metrics.rowStarts[rect.row_start] + inset;
      const width = metrics.colEnds[rect.col_end] - metrics.colStarts[rect.col_start] - inset * 2;
      const height = metrics.rowEnds[rect.row_end] - metrics.rowStarts[rect.row_start] - inset * 2;
      if (width <= 0 || height <= 0) continue;

      const fillRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      fillRect.setAttribute("x", String(x));
      fillRect.setAttribute("y", String(y));
      fillRect.setAttribute("width", String(width));
      fillRect.setAttribute("height", String(height));
      fillRect.setAttribute("rx", String(radius));
      fillRect.setAttribute("ry", String(radius));
      fillRect.setAttribute("fill", fillColor);
      fillRect.setAttribute("stroke", "none");
      fillStage.appendChild(fillRect);

      const haloRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      haloRect.setAttribute("x", String(x));
      haloRect.setAttribute("y", String(y));
      haloRect.setAttribute("width", String(width));
      haloRect.setAttribute("height", String(height));
      haloRect.setAttribute("rx", String(radius));
      haloRect.setAttribute("ry", String(radius));
      haloRect.setAttribute("fill", "none");
      haloRect.setAttribute("stroke", haloColor);
      haloRect.setAttribute("stroke-width", String(haloWidth));
      haloRect.setAttribute("stroke-linejoin", "round");
      haloRect.setAttribute("stroke-linecap", "round");
      haloRect.setAttribute("opacity", isLight ? "0.44" : "0.60");
      haloRect.style.filter = `drop-shadow(0 0 12px ${{glowColor}})`;
      lineStage.appendChild(haloRect);

      const borderRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      borderRect.setAttribute("x", String(x));
      borderRect.setAttribute("y", String(y));
      borderRect.setAttribute("width", String(width));
      borderRect.setAttribute("height", String(height));
      borderRect.setAttribute("rx", String(radius));
      borderRect.setAttribute("ry", String(radius));
      borderRect.setAttribute("fill", "none");
      borderRect.setAttribute("stroke", crispStroke);
      borderRect.setAttribute("stroke-width", String(strokeWidth));
      borderRect.setAttribute("stroke-linejoin", "round");
      borderRect.setAttribute("stroke-linecap", "round");
      lineStage.appendChild(borderRect);

      const accentRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      accentRect.setAttribute("x", String(x));
      accentRect.setAttribute("y", String(y));
      accentRect.setAttribute("width", String(width));
      accentRect.setAttribute("height", String(height));
      accentRect.setAttribute("rx", String(radius));
      accentRect.setAttribute("ry", String(radius));
      accentRect.setAttribute("fill", "none");
      accentRect.setAttribute("stroke", group.color);
      accentRect.setAttribute("stroke-width", String(Math.max(1.4, strokeWidth - 1)));
      accentRect.setAttribute("stroke-linejoin", "round");
      accentRect.setAttribute("stroke-linecap", "round");
      accentRect.setAttribute("opacity", isLight ? "0.92" : "0.96");
      lineStage.appendChild(accentRect);
    }}
  }});

  const foot = document.createElement("div");
  foot.className = "kmap-foot";
  foot.textContent = `Colored outlines correspond to the minimal groups induced by the current CNF or DNF result. Focus value: ${{DATA.focus_value}}.`;
  root.appendChild(foot);
  updateFrameHeight();
}}

function updateFrameHeight() {{
  window.requestAnimationFrame(() => {{
    const height = Math.ceil(document.documentElement.scrollHeight);
    try {{
      window.parent.postMessage({{
        isStreamlitMessage: true,
        type: "streamlit:setFrameHeight",
        height,
      }}, "*");
    }} catch (error) {{
      // ignore
    }}
  }});
}}

render();
if ("ResizeObserver" in window) {{
  new ResizeObserver(updateFrameHeight).observe(document.getElementById("kmap-root"));
}}
</script>
</body>
</html>"""


def _mount_shortcut_autocomplete() -> None:
    suggestions_json = json.dumps(get_shortcut_suggestions(), ensure_ascii=False)
    st.components.v1.html(
        rf"""
        <script>
        (() => {{
          const suggestions = {suggestions_json};
          const parentWindow = window.parent;
          const parentDoc = parentWindow && parentWindow.document;
          if (!parentWindow || !parentDoc) return;

          const existingState = parentWindow.__logicShortcutAutocomplete;
          if (existingState && typeof existingState.cleanup === "function") {{
            existingState.cleanup();
          }}

          const STYLE_ID = "logic-shortcut-autocomplete-style";
          const POPUP_ID = "logic-shortcut-autocomplete-popup";
          const INPUT_SELECTOR = 'input[aria-label="Formula"]';
          const POPUP_OFFSET = 8;
          const POPUP_THEME_DARK = {{
            bg: "rgba(15, 23, 42, 0.97)",
            border: "#334155",
            shadow: "rgba(2, 6, 23, 0.56)",
            glow: "rgba(56, 189, 248, 0.12)",
            header_from: "rgba(13, 31, 53, 0.98)",
            header_to: "rgba(24, 13, 53, 0.98)",
            header_text: "#94a3b8",
            command: "#e2e8f0",
            symbol_text: "#7dd3fc",
            symbol_bg: "rgba(56, 189, 248, 0.12)",
            symbol_border: "rgba(56, 189, 248, 0.34)",
            kind_text: "#c4b5fd",
            kind_bg: "rgba(167, 139, 250, 0.12)",
            kind_border: "rgba(167, 139, 250, 0.28)",
            hover_bg: "rgba(56, 189, 248, 0.10)",
            active_bg: "rgba(56, 189, 248, 0.16)",
            active_ring: "#f59e0b",
            foot_text: "#94a3b8",
            foot_bg: "rgba(2, 6, 23, 0.92)",
            foot_border: "#1e293b",
            scrollbar_track: "rgba(15, 23, 42, 0.16)",
            scrollbar_thumb: "#334155",
            scrollbar_thumb_hover: "#475569",
          }};
          const POPUP_THEME_LIGHT = {{
            bg: "rgba(255, 255, 255, 0.98)",
            border: "#d1d5db",
            shadow: "rgba(17, 24, 39, 0.12)",
            glow: "rgba(21, 128, 61, 0.08)",
            header_from: "rgba(232, 245, 233, 0.98)",
            header_to: "rgba(255, 247, 237, 0.98)",
            header_text: "#6b7280",
            command: "#111827",
            symbol_text: "#15803d",
            symbol_bg: "rgba(22, 163, 74, 0.08)",
            symbol_border: "rgba(21, 128, 61, 0.22)",
            kind_text: "#b45309",
            kind_bg: "rgba(217, 119, 6, 0.08)",
            kind_border: "rgba(217, 119, 6, 0.22)",
            hover_bg: "rgba(22, 163, 74, 0.07)",
            active_bg: "rgba(22, 163, 74, 0.12)",
            active_ring: "#ea580c",
            foot_text: "#6b7280",
            foot_bg: "rgba(249, 250, 251, 0.96)",
            foot_border: "#e5e7eb",
            scrollbar_track: "rgba(229, 231, 235, 0.8)",
            scrollbar_thumb: "#cbd5e1",
            scrollbar_thumb_hover: "#94a3b8",
          }};

          function ensureStyle() {{
            let style = parentDoc.getElementById(STYLE_ID);
            if (!style) {{
              style = parentDoc.createElement("style");
              style.id = STYLE_ID;
              parentDoc.head.appendChild(style);
            }}
            style.textContent = `
              #${{POPUP_ID}} {{
                position: absolute;
                z-index: 999999;
                min-width: min(440px, calc(100vw - 24px));
                max-width: 600px;
                background: var(--logic-popup-bg);
                border: 1px solid var(--logic-popup-border);
                border-radius: 14px;
                box-shadow:
                  0 18px 40px var(--logic-popup-shadow),
                  0 0 0 1px var(--logic-popup-glow);
                backdrop-filter: blur(8px);
                overflow: hidden;
                display: none;
                font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
                color: var(--logic-popup-command);
              }}
              #${{POPUP_ID}}.visible {{
                display: block;
              }}
              #${{POPUP_ID}} .logic-shortcut-head {{
                display: grid;
                grid-template-columns: 76px minmax(128px, 1.4fr) minmax(170px, 2fr);
                gap: 12px;
                padding: 10px 14px 8px;
                background: linear-gradient(180deg, var(--logic-popup-header-from), var(--logic-popup-header-to));
                border-bottom: 1px solid var(--logic-popup-foot-border);
                font-size: 12px;
                font-weight: 700;
                color: var(--logic-popup-header-text);
                text-transform: uppercase;
                letter-spacing: 0.04em;
              }}
              #${{POPUP_ID}} .logic-shortcut-list {{
                max-height: 280px;
                overflow-y: auto;
                scrollbar-width: thin;
                scrollbar-color: var(--logic-popup-scrollbar-thumb) var(--logic-popup-scrollbar-track);
              }}
              #${{POPUP_ID}} .logic-shortcut-list::-webkit-scrollbar {{
                width: 10px;
              }}
              #${{POPUP_ID}} .logic-shortcut-list::-webkit-scrollbar-track {{
                background: var(--logic-popup-scrollbar-track);
              }}
              #${{POPUP_ID}} .logic-shortcut-list::-webkit-scrollbar-thumb {{
                background: var(--logic-popup-scrollbar-thumb);
                border-radius: 999px;
                border: 2px solid transparent;
                background-clip: padding-box;
              }}
              #${{POPUP_ID}} .logic-shortcut-list::-webkit-scrollbar-thumb:hover {{
                background: var(--logic-popup-scrollbar-thumb-hover);
                background-clip: padding-box;
              }}
              #${{POPUP_ID}} .logic-shortcut-row {{
                width: 100%;
                border: 0;
                background: transparent;
                display: grid;
                grid-template-columns: 76px minmax(128px, 1.4fr) minmax(170px, 2fr);
                gap: 12px;
                align-items: center;
                padding: 10px 14px;
                text-align: left;
                cursor: pointer;
                font-size: 14px;
                color: var(--logic-popup-command);
                transition: background .12s ease, box-shadow .12s ease;
              }}
              #${{POPUP_ID}} .logic-shortcut-row:hover {{
                background: var(--logic-popup-hover-bg);
              }}
              #${{POPUP_ID}} .logic-shortcut-row.active {{
                background: var(--logic-popup-active-bg);
                box-shadow: inset 3px 0 0 var(--logic-popup-active-ring);
              }}
              #${{POPUP_ID}} .logic-shortcut-row:focus-visible {{
                outline: 2px solid var(--logic-popup-active-ring);
                outline-offset: -2px;
              }}
              #${{POPUP_ID}} .logic-shortcut-symbol {{
                color: var(--logic-popup-symbol-text);
                background: var(--logic-popup-symbol-bg);
                border: 1px solid var(--logic-popup-symbol-border);
                border-radius: 10px;
                font-family: "DejaVu Sans", "Segoe UI Symbol", "Noto Sans Symbols 2", Arial, sans-serif;
                font-size: 24px;
                font-weight: 700;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                justify-self: start;
                width: 44px;
                height: 34px;
                line-height: 1;
              }}
              #${{POPUP_ID}} .logic-shortcut-command {{
                display: inline-flex;
                align-items: center;
                justify-self: start;
                padding: 3px 9px;
                border-radius: 999px;
                background: var(--logic-popup-symbol-bg);
                border: 1px solid var(--logic-popup-symbol-border);
                color: var(--logic-popup-command);
                font-size: 13px;
                font-weight: 600;
              }}
              #${{POPUP_ID}} .logic-shortcut-aliases {{
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                align-items: center;
              }}
              #${{POPUP_ID}} .logic-shortcut-alias-chip {{
                display: inline-flex;
                align-items: center;
                justify-content: center;
                padding: 3px 9px;
                border-radius: 999px;
                background: var(--logic-popup-kind-bg);
                border: 1px solid var(--logic-popup-kind-border);
                color: var(--logic-popup-kind-text);
                font-size: 12px;
                font-weight: 600;
              }}
              #${{POPUP_ID}} .logic-shortcut-foot {{
                padding: 9px 14px 11px;
                border-top: 1px solid var(--logic-popup-foot-border);
                font-size: 12px;
                color: var(--logic-popup-foot-text);
                background: var(--logic-popup-foot-bg);
              }}
            `;
          }}

          function ensurePopup() {{
            let popup = parentDoc.getElementById(POPUP_ID);
            if (popup) return popup;

            popup = parentDoc.createElement("div");
            popup.id = POPUP_ID;
            popup.innerHTML = `
              <div class="logic-shortcut-head">
                <span>Symbol</span>
                <span>Command</span>
                <span>Aliases</span>
              </div>
              <div class="logic-shortcut-list"></div>
              <div class="logic-shortcut-foot">Use arrows plus Enter or Tab to insert.</div>
            `;
            parentDoc.body.appendChild(popup);
            return popup;
          }}

          function escapeHtml(text) {{
            return text
              .replaceAll("&", "&amp;")
              .replaceAll("<", "&lt;")
              .replaceAll(">", "&gt;")
              .replaceAll('"', "&quot;")
              .replaceAll("'", "&#39;");
          }}

          function setNativeValue(input, value) {{
            const descriptor = Object.getOwnPropertyDescriptor(
              window.HTMLInputElement.prototype,
              "value"
            );
            if (descriptor && descriptor.set) {{
              descriptor.set.call(input, value);
            }} else {{
              input.value = value;
            }}
            input.dispatchEvent(new Event("input", {{ bubbles: true }}));
          }}

          function getTokenMatch(input) {{
            const caret = input.selectionStart ?? input.value.length;
            const prefix = input.value.slice(0, caret);
            const match = prefix.match(/(?:^|[^A-Za-z0-9_])([/\\][A-Za-z]*)$/);
            if (!match) return null;
            return {{
              token: match[1],
              start: caret - match[1].length,
              end: caret,
            }};
          }}

          function filterSuggestions(token) {{
            const lowered = token.toLowerCase();
            return suggestions.filter((item) => {{
              const candidates = [item.command, ...(item.triggers || []), ...(item.aliases || [])];
              return candidates.some((candidate) =>
                String(candidate).toLowerCase().startsWith(lowered)
              );
            }});
          }}

          function positionPopup(input, popup) {{
            const rect = input.getBoundingClientRect();
            const viewportPadding = 12;
            const availableWidth = Math.max(320, parentWindow.innerWidth - viewportPadding * 2);
            const popupWidth = Math.min(Math.max(rect.width, 440), 600, availableWidth);
            const viewportLeft = Math.min(
              Math.max(rect.left, viewportPadding),
              parentWindow.innerWidth - popupWidth - viewportPadding
            );
            popup.style.left = `${{parentWindow.scrollX + viewportLeft}}px`;
            popup.style.top = `${{parentWindow.scrollY + rect.bottom + POPUP_OFFSET}}px`;
            popup.style.width = `${{popupWidth}}px`;
          }}

          function applyPopupTheme(themeName) {{
            const colors = themeName === "light" ? POPUP_THEME_LIGHT : POPUP_THEME_DARK;
            popup.dataset.theme = themeName;
            for (const [name, value] of Object.entries(colors)) {{
              popup.style.setProperty(`--logic-popup-${{name.replaceAll("_", "-")}}`, value);
            }}
          }}

          function parseVisibleRgb(color) {{
            if (!color) return null;
            const match = String(color).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?/i);
            if (!match) return null;
            const alpha = match[4] === undefined ? 1 : Number(match[4]);
            if (!Number.isFinite(alpha) || alpha <= 0.02) return null;
            return [Number(match[1]), Number(match[2]), Number(match[3])];
          }}

          function luminance(rgb) {{
            return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
          }}

          function themeFromElementBackground(element) {{
            if (!element) return null;
            let current = element;
            while (current && current.nodeType === Node.ELEMENT_NODE) {{
              const style = parentWindow.getComputedStyle(current);
              const bg = parseVisibleRgb(style.backgroundColor);
              if (bg) {{
                return luminance(bg) >= 150 ? "light" : "dark";
              }}
              current = current.parentElement;
            }}
            return null;
          }}

          function detectStreamlitTheme(referenceInput = null) {{
            try {{
              const root = parentDoc.documentElement;
              const body = parentDoc.body;
              const appEl = parentDoc.querySelector(".stApp")
                || parentDoc.querySelector('[data-testid="stAppViewContainer"]')
                || parentDoc.querySelector("main");

              for (const element of [root, body, appEl]) {{
                const themeValue = String(
                  element?.getAttribute("data-theme")
                  || element?.dataset?.theme
                  || ""
                ).toLowerCase();
                if (themeValue.includes("light")) return "light";
                if (themeValue.includes("dark")) return "dark";
              }}

              const inputTheme = themeFromElementBackground(referenceInput);
              if (inputTheme) return inputTheme;

              for (const element of [appEl, body, root]) {{
                const theme = themeFromElementBackground(element);
                if (theme) return theme;
              }}
            }} catch (error) {{
              // ignore theme detection fallbacks
            }}
            return parentWindow.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
          }}

          ensureStyle();
          const popup = ensurePopup();
          const list = popup.querySelector(".logic-shortcut-list");
          let themeObserver = null;
          let lastTheme = null;

          function refreshPopupTheme(referenceInput = null) {{
            const theme = detectStreamlitTheme(referenceInput);
            if (theme === lastTheme) return;
            lastTheme = theme;
            applyPopupTheme(theme);
          }}

          refreshPopupTheme();
          if (parentWindow.MutationObserver) {{
            themeObserver = new parentWindow.MutationObserver(() => {{
              refreshPopupTheme();
            }});
            const observerConfig = {{
              attributes: true,
              subtree: false,
              attributeFilter: ["class", "style", "data-theme"],
            }};
            if (parentDoc.documentElement) {{
              themeObserver.observe(parentDoc.documentElement, observerConfig);
            }}
            if (parentDoc.body) {{
              themeObserver.observe(parentDoc.body, observerConfig);
            }}
          }}

          let activeInput = null;
          let activeItems = [];
          let activeIndex = 0;
          let detachCurrent = null;

          function hidePopup() {{
            popup.classList.remove("visible");
            activeItems = [];
            activeIndex = 0;
          }}

          function applySuggestion(item) {{
            if (!activeInput) return;
            const match = getTokenMatch(activeInput);
            if (!match) {{
              hidePopup();
              return;
            }}

            const nextValue =
              activeInput.value.slice(0, match.start)
              + item.symbol
              + activeInput.value.slice(match.end);
            const caret = match.start + item.symbol.length;

            setNativeValue(activeInput, nextValue);
            parentWindow.requestAnimationFrame(() => {{
              try {{
                activeInput.focus();
                activeInput.setSelectionRange(caret, caret);
              }} catch (error) {{
                // ignore selection failures
              }}
            }});
            hidePopup();
          }}

          function scrollActiveRowIntoView() {{
            const activeRow = list.querySelector(".logic-shortcut-row.active");
            if (!activeRow) return;
            activeRow.scrollIntoView({{
              block: "nearest",
              inline: "nearest",
            }});
          }}

          function renderPopup(items, options = {{}}) {{
            activeItems = items;
            if (!items.length || !activeInput) {{
              hidePopup();
              return;
            }}

            refreshPopupTheme(activeInput);

            if (activeIndex >= items.length) {{
              activeIndex = 0;
            }}

            list.innerHTML = items
              .map((item, index) => `
                <button type="button" class="logic-shortcut-row ${{index === activeIndex ? "active" : ""}}" data-index="${{index}}">
                  <span class="logic-shortcut-symbol">${{escapeHtml(item.symbol)}}</span>
                  <span class="logic-shortcut-command">${{escapeHtml(item.command)}}</span>
                  <span class="logic-shortcut-aliases">
                    ${{(item.aliases || []).map((alias) => `
                      <span class="logic-shortcut-alias-chip">${{escapeHtml(alias)}}</span>
                    `).join("")}}
                  </span>
                </button>
              `)
              .join("");

            for (const row of list.querySelectorAll(".logic-shortcut-row")) {{
              row.addEventListener("mousedown", (event) => {{
                event.preventDefault();
                const index = Number(row.dataset.index);
                applySuggestion(activeItems[index]);
              }});
            }}

            positionPopup(activeInput, popup);
            popup.classList.add("visible");

            if (options.scrollActiveIntoView) {{
              scrollActiveRowIntoView();
            }}
          }}

          function updatePopup() {{
            if (!activeInput) {{
              hidePopup();
              return;
            }}

            const match = getTokenMatch(activeInput);
            if (!match) {{
              hidePopup();
              return;
            }}

            activeIndex = 0;
            renderPopup(filterSuggestions(match.token));
          }}

          function onInput() {{
            activeInput = this;
            updatePopup();
          }}

          function onFocus() {{
            activeInput = this;
            updatePopup();
          }}

          function onBlur() {{
            parentWindow.setTimeout(() => {{
              if (!popup.matches(":hover")) {{
                hidePopup();
              }}
            }}, 120);
          }}

          function onKeyDown(event) {{
            if (!popup.classList.contains("visible") || !activeItems.length) return;

            if (event.key === "ArrowDown") {{
              event.preventDefault();
              activeIndex = (activeIndex + 1) % activeItems.length;
              renderPopup(activeItems, {{ scrollActiveIntoView: true }});
              return;
            }}

            if (event.key === "ArrowUp") {{
              event.preventDefault();
              activeIndex = (activeIndex - 1 + activeItems.length) % activeItems.length;
              renderPopup(activeItems, {{ scrollActiveIntoView: true }});
              return;
            }}

            if (event.key === "Enter" || event.key === "Tab") {{
              event.preventDefault();
              applySuggestion(activeItems[activeIndex]);
              return;
            }}

            if (event.key === "Escape") {{
              event.preventDefault();
              hidePopup();
            }}
          }}

          function attachToInput(input) {{
            if (detachCurrent) {{
              detachCurrent();
              detachCurrent = null;
            }}

            const inputListener = onInput.bind(input);
            const focusListener = onFocus.bind(input);
            const blurListener = onBlur.bind(input);
            const keydownListener = onKeyDown.bind(input);

            input.addEventListener("input", inputListener);
            input.addEventListener("focus", focusListener);
            input.addEventListener("blur", blurListener);
            input.addEventListener("keydown", keydownListener);
            activeInput = input;
            refreshPopupTheme(input);

            detachCurrent = () => {{
              input.removeEventListener("input", inputListener);
              input.removeEventListener("focus", focusListener);
              input.removeEventListener("blur", blurListener);
              input.removeEventListener("keydown", keydownListener);
            }};
          }}

          function bindLatestInput() {{
            const input = parentDoc.querySelector(INPUT_SELECTOR);
            if (!input || input === activeInput) return;
            attachToInput(input);
          }}

          function onWindowUpdate() {{
            if (activeInput && popup.classList.contains("visible")) {{
              positionPopup(activeInput, popup);
            }}
          }}

          function onDocumentClick(event) {{
            if (
              popup.classList.contains("visible")
              && !popup.contains(event.target)
              && event.target !== activeInput
            ) {{
              hidePopup();
            }}
          }}

          bindLatestInput();
          const intervalId = parentWindow.setInterval(bindLatestInput, 600);
          parentWindow.addEventListener("resize", onWindowUpdate, true);
          parentDoc.addEventListener("scroll", onWindowUpdate, true);
          parentDoc.addEventListener("click", onDocumentClick);

          parentWindow.__logicShortcutAutocomplete = {{
            cleanup() {{
              if (detachCurrent) {{
                detachCurrent();
                detachCurrent = null;
              }}
              if (themeObserver) {{
                themeObserver.disconnect();
                themeObserver = null;
              }}
              parentWindow.clearInterval(intervalId);
              parentWindow.removeEventListener("resize", onWindowUpdate, true);
              parentDoc.removeEventListener("scroll", onWindowUpdate, true);
              parentDoc.removeEventListener("click", onDocumentClick);
              hidePopup();
            }},
          }};
        }})();
        </script>
        """,
        height=0,
    )


def get_prolog() -> Prolog:
    prolog = Prolog()
    prolog.consult(str(PARSER_FILE))
    prolog.consult(str(CNF_DNF_FILE))
    prolog.consult(str(CANONICAL_FILE))
    prolog.consult(str(MINIMAL_FILE))
    prolog.consult(str(TRUTH_TABLE_FILE))
    prolog.consult(str(TSEITIN_FILE))
    prolog.consult(str(SKOLEM_FILE))
    return prolog


def parse_formula_expr(formula: str):
    """Parse formula text via SWI-Prolog (same as Analyze) and return ExprNode for UI."""
    # Normalize user shortcuts before sending text into Prolog.
    normalized = _prepare_formula_input(formula)
    if normalized.lower() in {"true", "false"}:
        return prolog_ast_to_exprnode(normalized.lower())
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    parse_result = list(
        prolog.query(f"parse_propositional_formula({prolog_input}, AST)", maxresult=1)
    )
    if not parse_result:
        raise ValueError("Parsing failed for this input.")
    return prolog_ast_to_exprnode(parse_result[0]["AST"])


def analyze_formula(formula: str) -> tuple[str, str]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()

    token_result = list(prolog.query(f"tokenize({prolog_input}, Tokens)", maxresult=1))
    parse_result = list(
        prolog.query(f"parse_propositional_formula({prolog_input}, AST)", maxresult=1)
    )

    if not token_result:
        raise ValueError("Tokenization failed for this input.")
    if not parse_result:
        raise ValueError("Parsing failed for this input.")

    tokens = str(token_result[0]["Tokens"])
    ast = str(parse_result[0]["AST"])
    return tokens, ast


def cnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    cnf_result = list(
        prolog.query(
            f"cnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not cnf_result:
        raise ValueError("CNF conversion failed for this input.")

    return str(cnf_result[0]["Pretty"])


def dnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    dnf_result = list(
        prolog.query(
            f"dnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not dnf_result:
        raise ValueError("DNF conversion failed for this input.")

    return str(dnf_result[0]["Pretty"])


def canonical_cnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    canonical_cnf_result = list(
        prolog.query(
            f"canonical_cnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not canonical_cnf_result:
        raise ValueError("Canonical CNF conversion failed for this input.")

    return str(canonical_cnf_result[0]["Pretty"])


def canonical_dnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    canonical_dnf_result = list(
        prolog.query(
            f"canonical_dnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not canonical_dnf_result:
        raise ValueError("Canonical DNF conversion failed for this input.")

    return str(canonical_dnf_result[0]["Pretty"])


def minimal_cnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    minimal_cnf_result = list(
        prolog.query(
            f"minimal_cnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not minimal_cnf_result:
        raise ValueError("Minimal CNF conversion failed for this input.")

    return str(minimal_cnf_result[0]["Pretty"])


def minimal_dnf_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    minimal_dnf_result = list(
        prolog.query(
            f"minimal_dnf_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )

    if not minimal_dnf_result:
        raise ValueError("Minimal DNF conversion failed for this input.")

    return str(minimal_dnf_result[0]["Pretty"])


def _swipl_atom_str(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    text = str(value)
    if len(text) >= 2 and text[0] == text[-1] == "'":
        return text[1:-1]
    return text


def _truth_table_cell_char(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, bytes):
        raw = value.decode("utf-8", errors="replace").lower()
        if raw == "na":
            return "-"
        if raw in {"true", "false"}:
            return "1" if raw == "true" else "0"
    if isinstance(value, str) and value.lower() == "na":
        return "-"
    if value is True:
        return "1"
    if value is False:
        return "0"
    if isinstance(value, int):
        if value == 1:
            return "1"
        if value == 0:
            return "0"
        if value == -1:
            return "-"
    s = _swipl_atom_str(value).lower()
    if s in {"true", "1"}:
        return "1"
    if s in {"false", "0"}:
        return "0"
    if s == "na":
        return "-"
    return "-"


def _truth_table_bits_list(raw: object) -> list[object]:
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return list(raw)
    if hasattr(raw, "args"):
        return list(getattr(raw, "args") or ())
    return [raw]


def _truth_table_unpack_row(
    raw: object,
) -> tuple[list[object], object, object, object] | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        inner = raw.strip()
        if inner.startswith("[") and inner.endswith("]"):
            try:
                parsed = ast.literal_eval(inner)
            except (SyntaxError, ValueError):
                parsed = None
            if isinstance(parsed, list) and len(parsed) >= 3:
                *bits_vals, f_v, md_v, mc_v = parsed
                return (list(bits_vals), f_v, md_v, mc_v)
        return None
    if isinstance(raw, (list, tuple)) and len(raw) >= 3:
        seq = list(raw)
        bits_vals, f_v, md_v, mc_v = seq[:-3], seq[-3], seq[-2], seq[-1]
        return (list(bits_vals), f_v, md_v, mc_v)
    if hasattr(raw, "args"):
        args = getattr(raw, "args")
        if args is not None and len(args) == 4:
            bits_raw, f_v, md_v, mc_v = args
            return (_truth_table_bits_list(bits_raw), f_v, md_v, mc_v)
    return None


def _truth_table_unpack_props(raw: object) -> dict[str, object]:
    args: tuple[object, ...] | list[object]
    if raw is None:
        raise ValueError("Unexpected truth-table summary from Prolog.")
    if isinstance(raw, (list, tuple)) and len(raw) == 8:
        args = raw
    elif hasattr(raw, "args") and getattr(raw, "args") is not None:
        args = tuple(getattr(raw, "args"))
        if len(args) != 8:
            raise ValueError("Unexpected truth-table summary from Prolog.")
    else:
        raise ValueError("Unexpected truth-table summary from Prolog.")
    (
        classification,
        is_tautology,
        is_contradiction,
        is_satisfiable,
        equiv,
        mdnf_ok,
        mcnf_ok,
        message,
    ) = args
    return {
        "classification": _swipl_atom_str(classification),
        "is_tautology": is_tautology is True or _swipl_atom_str(is_tautology).lower() == "true",
        "is_contradiction": is_contradiction is True
        or _swipl_atom_str(is_contradiction).lower() == "true",
        "is_satisfiable": is_satisfiable is True
        or _swipl_atom_str(is_satisfiable).lower() == "true",
        "equivalent_mdnf_mcnf": equiv is True or _swipl_atom_str(equiv).lower() == "true",
        "mdnf_available": mdnf_ok is True or _swipl_atom_str(mdnf_ok).lower() == "true",
        "mcnf_available": mcnf_ok is True or _swipl_atom_str(mcnf_ok).lower() == "true",
        "minimal_message": _repair_swipl_utf8_mojibake(_swipl_atom_str(message)),
    }


def truth_table_bundle(
    formula: str,
) -> tuple[list[dict[str, str]], str, str, dict[str, bool | str]]:
    """Truth table via truth_table.pl; Python only shapes rows for the UI."""
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            "truth_table_report("
            f"{prolog_input}, VarNames, Rows, MDNFPretty, MCNFPretty, Props)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError("Truth table computation failed for this input.")
    binding = result[0]
    var_names_raw = binding["VarNames"]
    rows_raw = binding["Rows"]
    mdnf_text = _repair_swipl_utf8_mojibake(_swipl_atom_str(binding["MDNFPretty"]))
    mcnf_text = _repair_swipl_utf8_mojibake(_swipl_atom_str(binding["MCNFPretty"]))
    props_core = _truth_table_unpack_props(binding["Props"])

    var_names: list[str] = []
    if isinstance(var_names_raw, (list, tuple)):
        var_names = [_swipl_atom_str(v) for v in var_names_raw]
    elif var_names_raw is not None and hasattr(var_names_raw, "args"):
        var_names = [_swipl_atom_str(v) for v in (var_names_raw.args or ())]

    rows_in: list[object]
    if isinstance(rows_raw, (list, tuple)):
        rows_in = list(rows_raw)
    elif rows_raw is not None and hasattr(rows_raw, "args"):
        rows_in = list(rows_raw.args or ())
    else:
        rows_in = []

    table_rows: list[dict[str, str]] = []
    for raw_row in rows_in:
        unpacked = _truth_table_unpack_row(raw_row)
        if unpacked is None:
            continue
        bits_vals, f_v, md_v, mc_v = unpacked
        row: dict[str, str] = {}
        for name, bit in zip(var_names, bits_vals):
            row[name] = _truth_table_cell_char(bit)
        row["F"] = _truth_table_cell_char(f_v)
        row["MDNF"] = _truth_table_cell_char(md_v)
        row["MCNF"] = _truth_table_cell_char(mc_v)
        table_rows.append(row)

    mdnf_ok = bool(props_core["mdnf_available"])
    mcnf_ok = bool(props_core["mcnf_available"])
    table_props: dict[str, bool | str] = {
        "is_tautology": bool(props_core["is_tautology"]),
        "is_contradiction": bool(props_core["is_contradiction"]),
        "is_satisfiable": bool(props_core["is_satisfiable"]),
        "equivalent_mdnf_mcnf": bool(props_core["equivalent_mdnf_mcnf"]),
        "classification": str(props_core["classification"]),
        "minimal_available": mdnf_ok and mcnf_ok,
        "minimal_any_available": mdnf_ok or mcnf_ok,
        "mdnf_available": mdnf_ok,
        "mcnf_available": mcnf_ok,
        "minimal_message": str(props_core["minimal_message"]),
    }
    return table_rows, mdnf_text, mcnf_text, table_props


def skolem_pretty_formula(formula: str) -> str:
    """Skolem normal form (pretty) via skolem.pl; input must be a predicate formula."""
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"skolem_pretty_from_input({prolog_input}, Pretty)", maxresult=1
        )
    )
    if not result:
        raise ValueError(
            "Skolemov normálny tvar zlyhal. Skúste predikátovú formulu "
            "(napr. `forall x. P(x)` s bodkou po kvantifikátore)."
        )
    return _repair_swipl_utf8_mojibake(str(result[0]["Pretty"]))


def skolem_steps_pretty(formula: str) -> tuple[str, str]:
    """Returns (prenex pretty string, Skolem SNF pretty string)."""
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"skolem_steps_pretty({prolog_input}, PrenexPretty, SkolemPretty)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(
            "Skolemov krok zlyhal. Skúste platnú predikátovú formulu "
            "s kvantifikátormi (`forall x. ...`, `exists y. ...`)."
        )
    return (
        _repair_swipl_utf8_mojibake(str(result[0]["PrenexPretty"])),
        _repair_swipl_utf8_mojibake(str(result[0]["SkolemPretty"])),
    )


def _split_args(s: str) -> list[str]:
    args, depth, buf, in_q = [], 0, [], False
    for c in s:
        if c == "'" and not in_q:
            in_q = True;  buf.append(c)
        elif c == "'" and in_q:
            in_q = False; buf.append(c)
        elif in_q:
            buf.append(c)
        elif c == '(':
            depth += 1; buf.append(c)
        elif c == ')':
            depth -= 1; buf.append(c)
        elif c == ',' and depth == 0:
            args.append(''.join(buf).strip()); buf = []
        else:
            buf.append(c)
    if buf:
        args.append(''.join(buf).strip())
    return args


def _parse_term(s: str):
    s = s.strip()
    if s.startswith("'") and s.endswith("'") and len(s) >= 2:
        return s[1:-1]          # unquote
    p = s.find('(')
    if p == -1:
        return s                # plain atom / number
    functor = s[:p].strip()
    inner   = s[p+1 : s.rfind(')')].strip()
    return (functor, [_parse_term(a) for a in _split_args(inner)])

def _tree_to_dict(t) -> dict:
    if isinstance(t, str):
        return {"type": "leaf", "label": t}

    functor, args = t

    if functor == "leaf" and len(args) == 1:
        a = args[0]
        if isinstance(a, tuple) and a[0] == "var" and a[1]:
            label = str(a[1][0])
        else:
            label = str(a)
        return {"type": "leaf", "label": label}

    if functor == "node1" and len(args) == 3:
        var_t, op_t, sub_t = args
        return {
            "type": "node",
            "label": str(op_t),
            "var": str(var_t),
            "children": [_tree_to_dict(sub_t)],
        }

    if functor == "node" and len(args) == 4:
        var_t, op_t, l_t, r_t = args
        return {
            "type": "node",
            "label": str(op_t),
            "var": str(var_t),
            "children": [_tree_to_dict(l_t), _tree_to_dict(r_t)],
        }

    return {"type": "leaf", "label": str(t)}

def _exprnode_to_tree_dict(node) -> dict:
    if node is None:
        return {"type": "leaf", "label": "?"}

    # variable / atom
    if getattr(node, "value", None) is not None and getattr(node, "left", None) is None and getattr(node, "right", None) is None:
        return {
            "type": "leaf",
            "label": str(node.value),
        }

    children = []
    if getattr(node, "left", None) is not None:
        children.append(_exprnode_to_tree_dict(node.left))
    if getattr(node, "right", None) is not None:
        children.append(_exprnode_to_tree_dict(node.right))

    # fallback for unary node stored in right only
    if not children and getattr(node, "value", None) is not None:
        return {
            "type": "leaf",
            "label": str(node.value),
        }

    return {
        "type": "node",
        "label": str(node.op),
        "children": children,
    }

def _prolog_text(value) -> str:
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8")
    return str(value)


def _repair_swipl_utf8_mojibake(s: str) -> str:
    """Undo UTF-8 bytes decoded as Latin-1 (common with pyswip + SWI on Windows)."""
    if not s or "\u2203" in s or "\u2200" in s:
        return s
    try:
        return s.encode("latin-1").decode("utf-8")
    except (UnicodeDecodeError, UnicodeEncodeError):
        return s

def _collect_tseitin_vars(tree: dict) -> list[str]:
    result: list[str] = []

    def walk(node: dict):
        if not isinstance(node, dict):
            return
        if node.get("type") == "node" and node.get("var"):
            result.append(str(node["var"]))
        for child in node.get("children", []):
            walk(child)

    walk(tree)
    return result


def tseitin_transform(formula: str):
    """
    Returns (tree_dict, full_formula_str, node_info_map).
    """
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()

    # 1) annotated tree
    tree_res = list(prolog.query(f"tseitin_annotated_tree({prolog_input}, Tree)", maxresult=1))
    if not tree_res:
        raise ValueError(
            "Tseitin transformation failed – check that the formula is valid.\n"
            "Supported operators: ~, &, |, ->, <->"
        )
    tree_raw  = str(tree_res[0]["Tree"])
    tree_obj  = _parse_term(tree_raw)
    tree_dict = _tree_to_dict(tree_obj)

    # 2) pretty formula
    pretty_res = list(
        prolog.query(f"tseitin_pretty_from_input({prolog_input}, Pretty)", maxresult=1)
    )
    if not pretty_res:
        raise ValueError("Tseitin pretty output failed.")

    full_formula_str = _prolog_text(pretty_res[0]["Pretty"])

    node_info_map: dict[str, dict[str, str]] = {}
    tseitin_vars = _collect_tseitin_vars(tree_dict)

    for var_name in tseitin_vars:
        var_atom = _to_prolog_atom(var_name)
        info_res = list(
            prolog.query(
                f"tseitin_node_pretty_info({prolog_input}, {var_atom}, EqPretty, ClauseFormulaPretty)",
                maxresult=1,
            )
        )
        if info_res:
            node_info_map[var_name] = {
                "equivalence": _prolog_text(info_res[0]["EqPretty"]),
                "clauses": _prolog_text(info_res[0]["ClauseFormulaPretty"]),
            }

    return tree_dict, full_formula_str, node_info_map


def _render_tree_html(
    tree_dict: dict,
    node_info_map: dict | None = None,
    show_info_panel: bool = False,
    legend_variant: str = "formula",
) -> str:
    tree_json = json.dumps(tree_dict, ensure_ascii=False)
    info_json = json.dumps(node_info_map or {}, ensure_ascii=False)
    show_info_panel_js = "true" if show_info_panel else "false"
    legend_variant_js = json.dumps(legend_variant, ensure_ascii=False)

    panel_html = ""
    panel_css = ""
    if show_info_panel:
        panel_css = """
  #nodepanel{
    position:absolute;
    top:60px;
    right:0px;
    width:min(420px, 42%);
    max-height:calc(100% - 24px);
    overflow:auto;
    background:rgba(15,23,42,.96);
    border:1px solid #334155;
    border-radius:10px;
    padding:12px;
    z-index:8;
    box-shadow:0 10px 30px rgba(0,0,0,.35);
  }
  #nodepanel.empty{
    color:#94a3b8;
  }
  .panel-title{
    color:#f8fafc;
    font-size:14px;
    font-weight:700;
    margin-bottom:10px;
  }
  .panel-block + .panel-block{
    margin-top:10px;
  }
  .panel-label{
    color:#94a3b8;
    font-size:11px;
    margin-bottom:4px;
    text-transform:uppercase;
    letter-spacing:.04em;
  }
  .panel-code{
    color:#e2e8f0;
    background:#020617;
    border:1px solid #1e293b;
    border-radius:8px;
    padding:10px;
    font-size:13px;
    line-height:1.45;
    white-space:pre-wrap;
    word-break:break-word;
  }
"""
        panel_html = """
  <div id="nodepanel" class="empty"></div>
"""

    return fr"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  :root{{
    /* fallback before JS applyTheme() sets full palette */
    --bg:#0d1117;
    --tip_text:#e2e8f0;
    --btn_border:#334155;
  }}
  html,body{{width:100%;height:100%;background:var(--bg);overflow:hidden}}
  body{{font-family:'JetBrains Mono','Fira Code','Consolas',monospace}}
  #wrap{{width:100%;height:100%;position:relative}}
  svg{{width:100%;height:100%}}

  .edge{{fill:none;stroke:var(--edge);stroke-width:2px}}

  .n-op circle{{
    fill:var(--op_fill);
    stroke:var(--op_stroke);
    stroke-width:2.5px;
    cursor:pointer;
    transition:filter .15s, stroke .15s, stroke-width .15s
  }}
  .n-op circle:hover{{filter:drop-shadow(0 0 7px var(--op_glow))}}
  .n-op.selected circle{{
    stroke:var(--selected_stroke);
    stroke-width:3.5px;
    filter:drop-shadow(0 0 8px var(--selected_glow));
  }}
  .n-op .lbl{{
    fill:var(--op_label);
    font-size:15px;
    font-weight:700;
    text-anchor:middle;
    dominant-baseline:central;
    pointer-events:none
  }}

  .n-leaf circle{{
    fill:var(--leaf_fill);
    stroke:var(--leaf_stroke);
    stroke-width:2.5px;
    cursor:grab;
    transition:filter .15s
  }}
  .n-leaf circle:hover{{filter:drop-shadow(0 0 7px var(--leaf_glow))}}
  .n-leaf.dragging circle{{cursor:grabbing}}
  .n-leaf .lbl{{
    fill:var(--leaf_label);
    font-size:15px;
    font-weight:600;
    text-anchor:middle;
    dominant-baseline:central;
    pointer-events:none
  }}

  .badge-bg{{fill:var(--badge_bg);stroke:var(--badge_stroke);stroke-width:1.2px}}
  .badge{{
    fill:var(--badge_label);
    font-size:11px;
    font-weight:700;
    text-anchor:middle;
    dominant-baseline:central;
    pointer-events:none
  }}

  #tip{{
    position:absolute;
    background:var(--tip_bg);
    border:1px solid var(--tip_border);
    border-radius:7px;
    padding:5px 13px;
    font-size:12px;
    color:var(--tip_text);
    pointer-events:none;
    opacity:0;
    transition:opacity .12s;
    white-space:nowrap;
    z-index:9
  }}

  {panel_css}

  .ctrl{{position:absolute;bottom:10px;right:12px;display:flex;gap:5px}}
  #legend{{
    position:absolute;
    left:12px;
    top:10px;
    font-size:13px;
    line-height:1.35;
    color:var(--tip_text);
    padding:0;
    z-index:7;
    max-width:min(78%, 920px);
  }}
  #nodepanel{{
    background:var(--panel_bg);
    border-color:var(--panel_border);
    box-shadow:0 10px 30px var(--panel_shadow);
  }}
  #nodepanel.empty{{color:var(--panel_empty_text)}}
  .panel-title{{color:var(--panel_title)}}
  .panel-label{{color:var(--panel_label)}}
  .panel-code{{
    color:var(--panel_code_text);
    background:var(--panel_code_bg);
    border-color:var(--panel_code_border);
  }}

  .cb{{
    background:var(--btn_bg);
    border:1px solid var(--btn_border);
    color:var(--btn_text);
    border-radius:5px;
    padding:3px 11px;
    font-size:11px;
    cursor:pointer;
    font-family:inherit
  }}
  .cb:hover{{background:var(--btn_hover_bg);color:var(--btn_hover_text)}}
</style>
</head>
<body>
<div id="wrap">
  <svg id="svg"></svg>
  <div id="legend"></div>
  <div id="tip"></div>

  {panel_html}

  <div class="ctrl">
    <button class="cb" onclick="reset()">Reset view</button>
    <button class="cb" onclick="resetLeaves()">Reset leaves</button>
    <button class="cb" onclick="zi()">＋</button>
    <button class="cb" onclick="zo()">－</button>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
<script>
const DATA = {tree_json};
const NODE_INFO = {info_json};
const SHOW_INFO_PANEL = {show_info_panel_js};
const LEGEND_VARIANT = {legend_variant_js};
const THEME_COMMON = {{
  selected_stroke:"#f59e0b",
  selected_glow:"#f59e0b"
}};
const DARK_THEME = {{
  ...THEME_COMMON,
  bg:"#0d1117",
  edge:"#1e3a5f",
  op_fill:"#0d1f35",
  op_stroke:"#38bdf8",
  op_glow:"#38bdf8",
  op_label:"#7dd3fc",
  leaf_fill:"#180d35",
  leaf_stroke:"#a78bfa",
  leaf_glow:"#a78bfa",
  leaf_label:"#c4b5fd",
  badge_bg:"#1c1200",
  badge_stroke:"#f59e0b",
  badge_label:"#fbbf24",
  tip_bg:"#0f172a",
  tip_border:"#38bdf8",
  tip_text:"#e2e8f0",
  btn_bg:"#1e293b",
  btn_border:"#334155",
  btn_text:"#94a3b8",
  btn_hover_bg:"#334155",
  btn_hover_text:"#e2e8f0",
  panel_bg:"rgba(15,23,42,.96)",
  panel_border:"#334155",
  panel_shadow:"rgba(0,0,0,.35)",
  panel_empty_text:"#94a3b8",
  panel_title:"#f8fafc",
  panel_label:"#94a3b8",
  panel_code_bg:"#020617",
  panel_code_border:"#1e293b",
  panel_code_text:"#e2e8f0"
}};
const LIGHT_THEME = {{
  ...THEME_COMMON,
  bg:"#ffffff",
  edge:"#6b7280",
  op_fill:"#e8f5e9",
  op_stroke:"#15803d",
  op_glow:"#16a34a",
  op_label:"#14532d",
  leaf_fill:"#f3f4f6",
  leaf_stroke:"#374151",
  leaf_glow:"#111827",
  leaf_label:"#111827",
  badge_bg:"#fff7ed",
  badge_stroke:"#d97706",
  badge_label:"#b45309",
  tip_bg:"#ffffff",
  tip_border:"#6b7280",
  tip_text:"#111827",
  btn_bg:"#f3f4f6",
  btn_border:"#d1d5db",
  btn_text:"#374151",
  btn_hover_bg:"#e5e7eb",
  btn_hover_text:"#111827",
  panel_bg:"rgba(255,255,255,0.98)",
  panel_border:"#d1d5db",
  panel_shadow:"rgba(0,0,0,.12)",
  panel_empty_text:"#6b7280",
  panel_title:"#111827",
  panel_label:"#6b7280",
  panel_code_bg:"#f9fafb",
  panel_code_border:"#e5e7eb",
  panel_code_text:"#111827",
  selected_stroke:"#ea580c",
  selected_glow:"#fb923c"
}};

function applyTheme(colors) {{
  Object.entries(colors).forEach(([k, v]) => {{
    document.documentElement.style.setProperty(`--${{k}}`, String(v));
  }});
}}

function parseRgb(rgb) {{
  if (!rgb) return null;
  const m = String(rgb).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!m) return null;
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}}

function luminance([r, g, b]) {{
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}}

function detectStreamlitTheme() {{
  try {{
    const pDoc = window.parent.document;
    const root = pDoc.documentElement;
    const body = pDoc.body;

    const attrs = [
      root?.getAttribute("data-theme"),
      body?.getAttribute("data-theme"),
      root?.dataset?.theme,
      body?.dataset?.theme,
    ].filter(Boolean).map(v => String(v).toLowerCase());
    if (attrs.some(v => v.includes("light"))) return "light";
    if (attrs.some(v => v.includes("dark"))) return "dark";

    const appEl = pDoc.querySelector(".stApp") || body;
    const bg = window.parent.getComputedStyle(appEl).backgroundColor;
    const rgb = parseRgb(bg);
    if (rgb) return luminance(rgb) >= 150 ? "light" : "dark";
  }} catch (e) {{
    // fallback below
  }}

  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}}

let lastTheme = null;
function syncTheme() {{
  const theme = detectStreamlitTheme();
  if (theme === lastTheme) return;
  lastTheme = theme;
  applyTheme(theme === "dark" ? DARK_THEME : LIGHT_THEME);
  updateLegend(theme);
  if (SHOW_INFO_PANEL && !selectedTsVar) {{
    renderEmptyPanel();
  }}
}}

function updateLegend(theme) {{
  const legend = document.getElementById("legend");
  if (!legend) return;
  if (LEGEND_VARIANT === "tseitin") {{
    legend.textContent = theme === "light"
      ? "🟢 zelená = logická operácia, ⚫ tmavosivá = premenná, 🟠 oranžová = Tseitinova premenná · klik na operator zobrazí jeho lokálne klauzuly · listy možno presúvať myšou"
      : "🔵 modrá = logická operácia, 🟣 fialová = premenná, 🟡 zlatá = Tseitinova premenná · klik na operator zobrazí jeho lokálne klauzuly · listy možno presúvať myšou";
    return;
  }}
  legend.textContent = theme === "light"
    ? "🟢 zelená = logická operácia, ⚫ tmavosivá = premenná · listy možno presúvať myšou"
    : "🔵 modrá = logická operácia, 🟣 fialová = premenná · listy možno presúvať myšou";
}}

const parentThemeMedia = window.matchMedia("(prefers-color-scheme: dark)");
if (typeof parentThemeMedia.addEventListener === "function") {{
  parentThemeMedia.addEventListener("change", syncTheme);
}} else if (typeof parentThemeMedia.addListener === "function") {{
  parentThemeMedia.addListener(syncTheme);
}}

try {{
  const pDoc = window.parent.document;
  const obs = new MutationObserver(syncTheme);
  obs.observe(pDoc.documentElement, {{
    attributes: true,
    attributeFilter: ["class", "style", "data-theme"]
  }});
  if (pDoc.body) {{
    obs.observe(pDoc.body, {{
      attributes: true,
      attributeFilter: ["class", "style", "data-theme"]
    }});
  }}
  const appNode = pDoc.querySelector(".stApp");
  if (appNode) {{
    obs.observe(appNode, {{
      attributes: true,
      attributeFilter: ["class", "style", "data-theme"]
    }});
  }}
}} catch (e) {{
  // access to parent can fail in stricter embedding contexts
}}

const SYM = {{
  and:"∧", or:"∨", imp:"→", iff:"↔",
  not:"¬", neg:"¬", true:"⊤", false:"⊥"
}};
const sym = s => SYM[s] || s;

/* here we store manually moved leaf positions */
const LEAF_POS = new Map();
let selectedTsVar = null;

function esc(text) {{
  return String(text ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}}

function toH(n, path="0") {{
  const d = {{
    id: path,
    name: n.label,
    tsVar: n.var || null,
    leaf: n.type === "leaf"
  }};
  if (n.children && n.children.length) {{
    d.children = n.children.map((ch, i) => toH(ch, `${{path}}.${{i}}`));
  }}
  return d;
}}

const wrap = document.getElementById("wrap");
const tip  = document.getElementById("tip");
const svg  = d3.select("#svg");
const g    = svg.append("g");
syncTheme();

const zoom = d3.zoom()
  .scaleExtent([.15, 4])
  .on("zoom", e => g.attr("transform", e.transform));

svg.call(zoom);

function reset() {{
  svg.transition().duration(300).call(zoom.transform, d3.zoomIdentity);
}}

function zi() {{
  svg.transition().duration(180).call(zoom.scaleBy, 1.35);
}}

function zo() {{
  svg.transition().duration(180).call(zoom.scaleBy, .75);
}}

function resetLeaves() {{
  LEAF_POS.clear();
  draw();
}}

function renderEmptyPanel() {{
  if (!SHOW_INFO_PANEL) return;
  const panel = document.getElementById("nodepanel");
  if (!panel) return;

  const colorWord = lastTheme === "light" ? "zelený" : "modrý";

  panel.className = "empty";
  panel.innerHTML =
    `Klikni na ${{colorWord}} operator.<br/>` +
    "Zobrazí sa ekvivalencia uzla a lokálne klauzuly danej Tseitinovej premennej.";
}}

function renderNodePanel(tsVar, opName) {{
  if (!SHOW_INFO_PANEL) return;
  const panel = document.getElementById("nodepanel");
  if (!panel) return;

  const info = NODE_INFO[tsVar] || null;
  panel.className = "";

  if (!info) {{
    panel.innerHTML = `
      <div class="panel-title">Selected node: ${{esc(tsVar)}}</div>
      <div class="panel-block">
        <div class="panel-label">Operator</div>
        <div class="panel-code">${{esc(sym(opName))}}</div>
      </div>
      <div class="panel-block">
        <div class="panel-label">Info</div>
        <div class="panel-code">No local clause info available for this node.</div>
      </div>
    `;
    return;
  }}

  panel.innerHTML = `
    <div class="panel-title">Selected node: ${{esc(tsVar)}}</div>
    <div class="panel-block">
      <div class="panel-label">Equivalence</div>
      <div class="panel-code">${{esc(info.equivalence || "")}}</div>
    </div>
    <div class="panel-block">
      <div class="panel-label">Local clauses</div>
      <div class="panel-code">${{esc(info.clauses || "")}}</div>
    </div>
  `;
}}

function linkPath(d) {{
  const sx = d.source.fx;
  const sy = d.source.fy;
  const tx = d.target.fx;
  const ty = d.target.fy;
  const cy = (sy + ty) / 2;
  return `M${{sx}},${{sy}} C${{sx}},${{cy}} ${{tx}},${{cy}} ${{tx}},${{ty}}`;
}}

function draw() {{
  const W = wrap.clientWidth || 800;
  const H = wrap.clientHeight || 500;

  const root = d3.hierarchy(toH(DATA));
  const nNodes = root.descendants().length;
  const depth  = root.height;

  const nodeR = 26;
  const xGap = Math.max(70, Math.min(130, (W * .85) / Math.max(nNodes, 1)));
  const yGap = Math.max(90, (H * .75) / Math.max(depth, 1));

  d3.tree().nodeSize([xGap, yGap])(root);

  const nodes = root.descendants();
  const minX = d3.min(nodes, d => d.x);
  const maxX = d3.max(nodes, d => d.x);
  const ox   = (W - (maxX + minX)) / 2;
  const oy   = nodeR + 40;

  /* final coordinates used for rendering */
  nodes.forEach(d => {{
    const defaultX = d.x + ox;
    const defaultY = d.y + oy;

    if (d.data.leaf && LEAF_POS.has(d.data.id)) {{
      const saved = LEAF_POS.get(d.data.id);
      d.fx = saved.x;
      d.fy = saved.y;
    }} else {{
      d.fx = defaultX;
      d.fy = defaultY;
    }}
  }});

  g.selectAll("*").remove();

  const links = g.selectAll(".edge")
    .data(root.links())
    .join("path")
    .attr("class", "edge")
    .attr("d", linkPath);

  const dragLeaf = d3.drag()
    .on("start", function(event, d) {{
        d3.select(this).classed("dragging", true);
        tip.style.opacity = "0";

        const z = d3.zoomTransform(svg.node());
        const [mx, my] = d3.pointer(event, svg.node());
        const [gx, gy] = z.invert([mx, my]);

        d.dragOffsetX = d.fx - gx;
        d.dragOffsetY = d.fy - gy;
    }})
    .on("drag", function(event, d) {{
        const z = d3.zoomTransform(svg.node());
        const [mx, my] = d3.pointer(event, svg.node());
        const [gx, gy] = z.invert([mx, my]);

        d.fx = gx + (d.dragOffsetX || 0);
        d.fy = gy + (d.dragOffsetY || 0);

        LEAF_POS.set(d.data.id, {{ x: d.fx, y: d.fy }});

        d3.select(this).attr("transform", `translate(${{d.fx}},${{d.fy}})`);
        links.attr("d", linkPath);
    }})
    .on("end", function(event, d) {{
        d3.select(this).classed("dragging", false);
        delete d.dragOffsetX;
        delete d.dragOffsetY;
    }});

  const nd = g.selectAll(".nd")
    .data(nodes)
    .join("g")
    .attr("class", d => {{
      const base = d.data.leaf ? "n-leaf" : "n-op";
      const sel = (!d.data.leaf && d.data.tsVar && d.data.tsVar === selectedTsVar) ? " selected" : "";
      return "nd " + base + sel;
    }})
    .attr("transform", d => `translate(${{d.fx}},${{d.fy}})`)
    .on("mouseover", (ev, d) => {{
      const parts = d.data.leaf
        ? [`variable: ${{d.data.name}}`, `drag: enabled`]
        : (SHOW_INFO_PANEL
            ? [`operator: ${{sym(d.data.name)}}`, `click: show clauses`]
            : [`operator: ${{sym(d.data.name)}}`]);
      if (d.data.tsVar) parts.push(`tseitin: ${{d.data.tsVar}}`);
      tip.textContent = parts.join("  ·  ");
      tip.style.opacity = "1";
    }})
    .on("mousemove", ev => {{
      tip.style.left = (ev.offsetX + 16) + "px";
      tip.style.top  = (ev.offsetY - 12) + "px";
    }})
    .on("mouseout", () => {{
      tip.style.opacity = "0";
    }})
    .on("click", function(ev, d) {{
      if (!SHOW_INFO_PANEL) return;
      ev.stopPropagation();
      if (d.data.leaf || !d.data.tsVar) return;

      selectedTsVar = d.data.tsVar;
      g.selectAll(".nd")
        .classed("selected", x => !x.data.leaf && x.data.tsVar === selectedTsVar);

      renderNodePanel(d.data.tsVar, d.data.name);
    }});

  nd.append("circle").attr("r", nodeR);

  nd.append("text")
    .attr("class", "lbl")
    .text(d => d.data.leaf ? d.data.name : sym(d.data.name));

  nd.filter(d => d.data.tsVar).each(function(d) {{
    const el  = d3.select(this);
    const txt = d.data.tsVar;
    const bw  = txt.length * 7.5 + 12;
    const bh  = 18;

    el.append("rect")
      .attr("class", "badge-bg")
      .attr("x", -bw/2)
      .attr("y", -(nodeR + bh + 4))
      .attr("width", bw)
      .attr("height", bh)
      .attr("rx", 5);

    el.append("text")
      .attr("class", "badge")
      .attr("y", -(nodeR + 4 + bh/2))
      .text(txt);
  }});

  /* drag only for leaves */
  nd.filter(d => d.data.leaf).call(dragLeaf);

  /* initial centering */
  const padX = 70;
  const padY = 90;

  const extraLeft   = 40;
  const extraRight  = 40;
  const extraTop    = 70;
  const extraBottom = 40;

  const minNX = d3.min(nodes, d => d.fx) - extraLeft;
  const maxNX = d3.max(nodes, d => d.fx) + extraRight;
  const minNY = d3.min(nodes, d => d.fy) - extraTop;
  const maxNY = d3.max(nodes, d => d.fy) + extraBottom;

  const treeW = Math.max(1, maxNX - minNX);
  const treeH = Math.max(1, maxNY - minNY);

  const scaleX = (W - 2 * padX) / treeW;
  const scaleY = (H - 2 * padY) / treeH;
  const scale  = Math.min(scaleX, scaleY, 1);

  const tx = (W - treeW * scale) / 2 - minNX * scale;
  const ty = (H - treeH * scale) / 2 - minNY * scale;

  svg.call(
    zoom.transform,
    d3.zoomIdentity.translate(tx, ty).scale(scale)
  );

  if (SHOW_INFO_PANEL) {{
    if (selectedTsVar) {{
      const selectedNode = nodes.find(n => !n.data.leaf && n.data.tsVar === selectedTsVar);
      if (selectedNode) {{
        renderNodePanel(selectedNode.data.tsVar, selectedNode.data.name);
      }} else {{
        renderEmptyPanel();
      }}
    }} else {{
      renderEmptyPanel();
    }}
  }}
}}

draw();
new ResizeObserver(draw).observe(wrap);
</script>
</body>
</html>"""


st.set_page_config(page_title="Logic Formula Solver", layout="wide")

# Force Streamlit theme preference back to "System" on load by removing
# cached explicit light/dark selections from localStorage.
st.components.v1.html(
    """
    <script>
    (function () {
      try {
        const ls = (window.parent && window.parent.localStorage) || window.localStorage;
        if (!ls) return;
        const toRemove = [];
        for (let i = 0; i < ls.length; i += 1) {
          const key = ls.key(i);
          if (!key) continue;
          if (/^stActiveTheme/i.test(key)) {
            toRemove.push(key);
          }
        }
        toRemove.forEach((key) => ls.removeItem(key));
      } catch (e) {
        // ignore when storage is unavailable
      }
    })();
    </script>
    """,
    height=0,
)

st.markdown("<h1 style='text-align: center;'>Logic Formula Solver</h1>", unsafe_allow_html=True)
st.markdown(
    "<p style='text-align: center;'>Python UI (Streamlit) calling SWI-Prolog predicates via pyswip</p>",
    unsafe_allow_html=True,
)

if "formula" not in st.session_state:
    st.session_state["formula"] = "A->B"

left_col, main_col, side_col = st.columns([1, 2, 1])

with main_col:
    formula_col, random_formula_col = st.columns([5, 2], vertical_alignment="bottom")
    with formula_col:
        formula = st.text_input(
            "Formula",
            key="formula",
            help=(
                "Use notations like \\lor, \\land, \\neg, \\Rightarrow, and "
                "\\Leftrightarrow, or aliases such as |, &, !, ~, or, and, ->, and <->. "
                "The input is normalized to logical symbols automatically."
            ),
            on_change=_normalize_formula_widget,
        )
    with random_formula_col:
        st.button(
            "Random",
            on_click=_set_random_formula,
            help="Random Formula: generate a parser-safe random propositional formula.",
            width="stretch",
        )
    _mount_shortcut_autocomplete()
    st.caption("Type `/` or `\\` in the formula field to open the notation table. Use arrows plus Enter or Tab to insert the selected operator.")

    row1_col1, row1_col2, row1_col3, row1_col4 = st.columns(4)
    with row1_col1:
        analyze_clicked = st.button("Analyze")
    with row1_col2:
        cnf_clicked = st.button("CNF")
    with row1_col3:
        dnf_clicked = st.button("DNF")
    with row1_col4:
        canonical_cnf_clicked = st.button("Canon. CNF")
    
    row2_col1, row2_col2, row2_col3, row2_col4 = st.columns(4)
    with row2_col1:
        canonical_dnf_clicked = st.button("Canon. DNF")
    with row2_col2:
        minimal_cnf_clicked = st.button("Minimal CNF")
    with row2_col3:
        minimal_dnf_clicked = st.button("Minimal DNF")
    with row2_col4:
        skolem_clicked = st.button(
            "Skolem. SNF",
        )

    row3_col1, row3_col2, row3_col3 = st.columns(3)
    with row3_col1:
        truth_table_clicked = st.button("Truth table (MCNF/MDNF)")
    with row3_col2:
        tree_clicked = st.button("Formula tree")
    with row3_col3:
        tseitin_clicked = st.button("Tseitinova transformácia")

    if analyze_clicked:
        try:
            with st.spinner("Running Prolog..."):
                tokens_text, ast_text = analyze_formula(formula)
            st.success("Done")
            st.subheader("Tokens")
            st.code(tokens_text)
            st.subheader("AST")
            st.code(ast_text)
        except Exception as exc:
            st.error(str(exc))

    if cnf_clicked:
        try:
            with st.spinner("Running full CNF conversion..."):
                cnf_text = cnf_formula(formula)
            st.subheader("CNF Result")
            st.code(cnf_text)
        except Exception as exc:
            st.error(str(exc))

    if dnf_clicked:
        try:
            with st.spinner("Running full DNF conversion..."):
                dnf_text = dnf_formula(formula)
            st.subheader("DNF Result")
            st.code(dnf_text)
        except Exception as exc:
            st.error(str(exc))

    if canonical_cnf_clicked:
        try:
            with st.spinner("Running canonical CNF conversion..."):
                canonical_cnf_text = canonical_cnf_formula(formula)
            st.subheader("Canonical CNF Result")
            st.code(canonical_cnf_text)
        except Exception as exc:
            st.error(str(exc))

    if canonical_dnf_clicked:
        try:
            with st.spinner("Running canonical DNF conversion..."):
                canonical_dnf_text = canonical_dnf_formula(formula)
            st.subheader("Canonical DNF Result")
            st.code(canonical_dnf_text)
        except Exception as exc:
            st.error(str(exc))

    if minimal_cnf_clicked:
        try:
            with st.spinner("Running minimal CNF simplification..."):
                minimal_cnf_text = minimal_cnf_formula(formula)
            _render_normal_form_result("Minimal CNF", minimal_cnf_text, "cnf", source_formula=formula)
        except Exception as exc:
            st.error(str(exc))

    if minimal_dnf_clicked:
        try:
            with st.spinner("Running minimal DNF simplification..."):
                minimal_dnf_text = minimal_dnf_formula(formula)
            _render_normal_form_result("Minimal DNF", minimal_dnf_text, "dnf", source_formula=formula)
        except Exception as exc:
            st.error(str(exc))

    if skolem_clicked:
        try:
            with st.spinner("Prenex a Skolemov normálny tvar (Prolog)..."):
                prenex_text, skolem_text = skolem_steps_pretty(formula)
            st.markdown("---")
            st.subheader("Skolem normál form (SNF)")
            st.markdown("##### Prenex")
            st.code(prenex_text, language="text")
            st.markdown("##### Skolem")
            st.code(skolem_text, language="text")
            if not _predicate_formula_has_quantifiers(formula):
                st.info(
                    "Táto formula **neobsahuje žiadne kvantifikátory** (`forall` / `exists`). "
                    "Skolemov normálny tvar je teda nevýhodný pre túto formulu."
                )
        except Exception as exc:
            st.error(str(exc))

    if truth_table_clicked:
        try:
            table_rows, mdnf_text, mcnf_text, table_props = truth_table_bundle(formula)
            st.subheader("Truth Table")
            st.caption(
                "F je pôvodná formula; MDNF a MCNF sú minimálne normálne tvarys."
            )
            st.dataframe(table_rows, use_container_width=True)
            st.subheader("Truth Table Summary")
            summary_rows = [
                {
                    "Classification": table_props["classification"],
                    "Tautology": "True" if table_props["is_tautology"] else "False",
                    "Contradiction": "True" if table_props["is_contradiction"] else "False",
                    "Satisfiable": "True" if table_props["is_satisfiable"] else "False",
                }
            ]
            st.dataframe(summary_rows, use_container_width=True, hide_index=True)
            if table_props["mdnf_available"]:
                st.subheader("MDNF")
                st.code(mdnf_text)
            if table_props["mcnf_available"]:
                st.subheader("MCNF")
                st.code(mcnf_text)
            if not table_props["minimal_any_available"]:
                st.warning(
                    "Minimal MDNF/MCNF sa nepodarilo vypocitat pre tento vstup. "
                    "Pravdivostna tabulka je vypocitana z povodnej formuly."
                )
        except Exception as exc:
            st.error(str(exc))

    if tree_clicked:
        try:
            with st.spinner("Building interactive formula tree..."):
                expr = parse_formula_expr(formula)
                tree_dict = _exprnode_to_tree_dict(expr)
                tree_html = _render_tree_html(
                    tree_dict,
                    show_info_panel=False,
                    legend_variant="formula",
                )

            st.subheader("Formula Tree")
            st.components.v1.html(tree_html, height=700, scrolling=False)

        except Exception as exc:
            st.error(str(exc))

    if tseitin_clicked:
        try:
            with st.spinner("Volám tseitin.pl cez Prolog..."):
                tree_dict, full_formula_str, node_info_map = tseitin_transform(formula)

            st.markdown("---")
            st.markdown("## Tseitinova transformácia")

            # 1) výstupná formula
            st.markdown("### Výstupná formula (z Prologu)")
            st.code(full_formula_str, language="text")

            # 2) interaktívne strom
            st.markdown("### Anotovaný strom")
            tree_html = _render_tree_html(
                tree_dict,
                node_info_map,
                show_info_panel=True,
                legend_variant="tseitin",
            )
            st.components.v1.html(tree_html, height=620, scrolling=False)

        except Exception as exc:
            st.error(f"Chyba Tseitinovej transformácie:\n\n{exc}")

    st.caption(
        "Shortcuts are normalized automatically before analysis, for example "
        "`/neg A`, `/land`, `/lor`, `\\\\Rightarrow`, `/leftrightarrow`, `/forall`, `/exists`."
    )
    st.markdown("Examples: `A->B`, `(A->B)&~C`, `(A|B)<->C`, `/neg A /lor B`, `A \\\\Rightarrow B`")

with side_col:
    st.markdown(
        """
### Tokenizer Symbols
- `~` or `not` -> negation (`not`)
- `&` or `/\\` or `and` -> conjunction (`and`)
- `|` or `\\/` or `or` -> disjunction (`or`)
- `->` or `imp` -> implication (`imp`)
- `<->` or `iff` -> equivalence (`iff`)
- `(` -> left parenthesis (`lparen`)
- `)` -> right parenthesis (`rparen`)
- `A`, `B`, `x`, ... -> variable (`var(Name)`)

### Input Shortcuts
- `/neg` or `\\neg` -> `~`
- `/land` or `\\land` -> `&`
- `/lor` or `\\lor` -> `|`
- `/forall` or `\\forall` -> `forall`
- `/exists` or `\\exists` -> `exists`
- `/leftrightarrow` or `\\Leftrightarrow` -> `<->`
- `/imp`, `/to`, `/rightarrow`, or `\\Rightarrow` -> `->`
"""
    )
