:- use_module(library(plunit)).
:- use_module(library(random)).
:- ensure_loaded('../../cnf_dnf_mimi.pl').
:- ensure_loaded('../../canonical.pl').
:- ensure_loaded('../../minimal.pl').
:- ensure_loaded('../../tseitin.pl').
:- ensure_loaded('../../equivalence.pl').
:- ensure_loaded('../../parser_predicate.pl').
:- ensure_loaded('../../prenex.pl').

silently(Goal) :-
    with_output_to(string(_), Goal).

prefix_vars(N, Vars) :-
    AllVars = ['A', 'B', 'C', 'D'],
    length(Vars, N),
    append(Vars, _, AllVars).

same_truth_table(AstA, AstB, Vars) :-
    length(Vars, VarCount),
    generate_bit_patterns(VarCount, Rows),
    forall(member(Row, Rows),
           ( assignment_from_bits(Vars, Row, Assignment),
             eval_formula(AstA, Assignment, Value),
             eval_formula(AstB, Assignment, Value)
           )).

same_truth_as_input(Input, MinimizedText) :-
    parse_propositional_formula(Input, Ast),
    parse_propositional_formula(MinimizedText, MinimizedAst),
    extract_all_variables(Ast, Vars),
    same_truth_table(Ast, MinimizedAst, Vars).

dnf_metric(false, 0, 0) :- !.
dnf_metric(true, 1, 0) :- !.
dnf_metric(Ast, TermCount, LiteralCount) :-
    dnf_to_term_list(Ast, Terms),
    length(Terms, TermCount),
    maplist(term_literal_count, Terms, LiteralCounts),
    sum_list(LiteralCounts, LiteralCount).

cnf_metric(true, 0, 0) :- !.
cnf_metric(false, 1, 0) :- !.
cnf_metric(Ast, ClauseCount, LiteralCount) :-
    cnf_to_clause_list(Ast, Clauses),
    length(Clauses, ClauseCount),
    maplist(clause_literal_count, Clauses, LiteralCounts),
    sum_list(LiteralCounts, LiteralCount).

term_literal_count(true, 0) :- !.
term_literal_count(Term, Count) :-
    conjunction_to_literals(Term, Literals),
    length(Literals, Count).

clause_literal_count(false, 0) :- !.
clause_literal_count(Clause, Count) :-
    disjunction_to_literals(Clause, Literals),
    length(Literals, Count).

test_all_patterns(0, [[]]) :- !.
test_all_patterns(N, Patterns) :-
    N > 0,
    N1 is N - 1,
    test_all_patterns(N1, RestPatterns),
    findall([Bit | Rest],
            ( member(Bit, [0, 1, x]),
              member(Rest, RestPatterns)
            ),
            Patterns).

test_pattern_covers([], []).
test_pattern_covers([x | RestPattern], [_ | RestRow]) :- !,
    test_pattern_covers(RestPattern, RestRow).
test_pattern_covers([Bit | RestPattern], [Bit | RestRow]) :-
    Bit \== x,
    test_pattern_covers(RestPattern, RestRow).

test_pattern_literal_count([], 0).
test_pattern_literal_count([x | Rest], Count) :- !,
    test_pattern_literal_count(Rest, Count).
test_pattern_literal_count([_ | Rest], Count) :-
    test_pattern_literal_count(Rest, RestCount),
    Count is RestCount + 1.

test_valid_candidate(TargetRows, NonTargetRows, c(Pattern, LiteralCount, CoveredRows)) :-
    TargetRows = [FirstRow | _],
    length(FirstRow, VarCount),
    test_all_patterns(VarCount, Patterns),
    member(Pattern, Patterns),
    findall(Row,
            ( member(Row, TargetRows),
              test_pattern_covers(Pattern, Row)
            ),
            CoveredRows0),
    CoveredRows0 \= [],
    \+ ( member(Row, NonTargetRows),
         test_pattern_covers(Pattern, Row)
       ),
    sort(CoveredRows0, CoveredRows),
    test_pattern_literal_count(Pattern, LiteralCount).

test_combination(0, _, []) :- !.
test_combination(K, [Item | Rest], [Item | Combo]) :-
    K > 0,
    K1 is K - 1,
    test_combination(K1, Rest, Combo).
test_combination(K, [_ | Rest], Combo) :-
    K > 0,
    test_combination(K, Rest, Combo).

test_cover_rows([], _).
test_cover_rows([Row | Rest], CoveredRows) :-
    memberchk(Row, CoveredRows),
    test_cover_rows(Rest, CoveredRows).

test_selected_covers(TargetRows, SelectedCandidates) :-
    findall(Row,
            ( member(c(_, _, CandidateRows), SelectedCandidates),
              member(Row, CandidateRows)
            ),
            CoveredRows0),
    sort(CoveredRows0, CoveredRows),
    test_cover_rows(TargetRows, CoveredRows).

test_selected_literal_count([], 0).
test_selected_literal_count([c(_, LiteralCount, _) | Rest], Total) :-
    test_selected_literal_count(Rest, RestTotal),
    Total is LiteralCount + RestTotal.

bruteforce_best_metric([], _, 0, 0) :- !.
bruteforce_best_metric(TargetRows, [], 1, 0) :- TargetRows \= [], !.
bruteforce_best_metric(TargetRows, NonTargetRows, TermCount, LiteralCount) :-
    findall(Candidate,
            test_valid_candidate(TargetRows, NonTargetRows, Candidate),
            Candidates0),
    sort(Candidates0, Candidates),
    length(Candidates, MaxTerms),
    between(1, MaxTerms, TermCount),
    findall(Lits,
            ( test_combination(TermCount, Candidates, Selected),
              test_selected_covers(TargetRows, Selected),
              test_selected_literal_count(Selected, Lits)
            ),
            LiteralCounts),
    LiteralCounts \= [],
    min_list(LiteralCounts, LiteralCount),
    !.

check_minimal_forms(Input) :-
    parse_propositional_formula(Input, Ast),
    extract_all_variables(Ast, Vars),
    truth_rows(Ast, Vars, true, TrueRows),
    truth_rows(Ast, Vars, false, FalseRows),
    minimal_dnf_pretty_from_input(Input, DnfText),
    minimal_cnf_pretty_from_input(Input, CnfText),
    same_truth_as_input(Input, DnfText),
    same_truth_as_input(Input, CnfText),
    parse_propositional_formula(DnfText, DnfAst),
    parse_propositional_formula(CnfText, CnfAst),
    dnf_metric(DnfAst, DnfTerms, DnfLiterals),
    cnf_metric(CnfAst, CnfClauses, CnfLiterals),
    length(Vars, VarCount),
    ( VarCount =< 3 ->
        bruteforce_best_metric(TrueRows, FalseRows, DnfTerms, DnfLiterals),
        bruteforce_best_metric(FalseRows, TrueRows, CnfClauses, CnfLiterals)
    ;
        true
    ).

random_formula_ast(Vars, 0, var(V)) :- !,
    random_member(V, Vars).
random_formula_ast(Vars, Depth, Ast) :-
    Depth > 0,
    random_between(0, 8, Choice),
    Depth1 is Depth - 1,
    random_formula_ast_by_choice(Choice, Vars, Depth1, Ast).

random_formula_ast_by_choice(0, Vars, _, var(V)) :- !,
    random_member(V, Vars).
random_formula_ast_by_choice(1, Vars, Depth, not(A)) :- !,
    random_formula_ast(Vars, Depth, A).
random_formula_ast_by_choice(2, Vars, Depth, and(A, B)) :- !,
    random_formula_ast(Vars, Depth, A),
    random_formula_ast(Vars, Depth, B).
random_formula_ast_by_choice(3, Vars, Depth, or(A, B)) :- !,
    random_formula_ast(Vars, Depth, A),
    random_formula_ast(Vars, Depth, B).
random_formula_ast_by_choice(4, Vars, Depth, imp(A, B)) :- !,
    random_formula_ast(Vars, Depth, A),
    random_formula_ast(Vars, Depth, B).
random_formula_ast_by_choice(5, Vars, Depth, iff(A, B)) :- !,
    random_formula_ast(Vars, Depth, A),
    random_formula_ast(Vars, Depth, B).
random_formula_ast_by_choice(6, _, _, true) :- !.
random_formula_ast_by_choice(7, _, _, false) :- !.
random_formula_ast_by_choice(_, Vars, Depth, and(A, B)) :-
    random_formula_ast(Vars, Depth, A),
    random_formula_ast(Vars, Depth, B).

check_random_minimal_case :-
    random_between(1, 4, VarCount),
    prefix_vars(VarCount, VarNames),
    random_between(1, 3, Depth),
    random_formula_ast(VarNames, Depth, Ast),
    ast_to_symbols(Ast, Input),
    check_minimal_forms(Input).

:- begin_tests(tokenizer).

test(tokenizes_implication, true(Tokens == [var('A'), imp, var('B')])) :-
    tokenize('A->B', Tokens).

test(tokenizes_keyword_formula,
     true(Tokens == [not, lparen, var('A'), and, var('B'), rparen])) :-
    tokenize('not (A and B)', Tokens).

test(tokenizes_constants, true(Tokens == [true, or, false])) :-
    tokenize('true | false', Tokens).

test(rejects_unknown_character, [fail]) :-
    silently(tokenize('@', _)).

:- end_tests(tokenizer).

:- begin_tests(parser_propositional).

test(parses_operator_precedence,
     true(AST == or(var('A'), and(var('B'), var('C'))))) :-
    parse_propositional_formula('A|B&C', AST).

test(parses_parenthesized_negation,
     true(AST == not(or(var('A'), var('B'))))) :-
    parse_propositional_formula('~(A|B)', AST).

test(parses_constants,
     true(AST == or(true, false))) :-
    parse_propositional_formula('true|false', AST).

test(rejects_incomplete_formula, [fail]) :-
    silently(parse_propositional_formula('A&', _)).

:- end_tests(parser_propositional).

:- begin_tests(cnf_dnf_mimi).

test(cnf_rewrites_implication,
     true(Cnf == or(not(var('A')), var('B')))) :-
    cnf_from_input('A->B', Cnf).

test(dnf_distributes_conjunction_over_disjunction,
     true(Dnf == or(and(var('A'), var('B')), and(var('A'), var('C'))))) :-
    dnf_from_input('A&(B|C)', Dnf).

test(cnf_pretty_formats_symbol_output, true(Pretty == 'B | ~A')) :-
    cnf_pretty_from_input('A->B', Pretty).

test(rejects_invalid_formula, [fail]) :-
    silently(cnf_from_input('A&', _)).

:- end_tests(cnf_dnf_mimi).

:- begin_tests(canonical).

test(canonical_cnf_expands_missing_literals,
     true(Canonical ==
          and(or(not(var('A')), var('B')),
              and(or(not(var('B')), var('A')),
                  or(var('A'), var('B')))))) :-
    canonical_cnf_from_input('A&B', Canonical).

test(canonical_dnf_expands_missing_literals,
     true(Canonical ==
          or(and(not(var('A')), var('B')),
             or(and(not(var('B')), var('A')),
                and(var('A'), var('B')))))) :-
    once(canonical_dnf_from_input('A|B', Canonical)).

test(canonical_cnf_pretty_formats_expanded_result,
     true(Pretty == '(B | A) & (A | ~B) & (B | ~A)')) :-
    canonical_cnf_pretty_from_input('A&B', Pretty).

:- end_tests(canonical).

:- begin_tests(minimal).

test(minimal_cnf_removes_subsumed_clause_left_associative,
     true(Minimal == var('A'))) :-
    minimal_cnf_from_input('A&(A|B)', Minimal).

test(minimal_cnf_removes_subsumed_clause_right_associative,
     true(Minimal == var('A'))) :-
    minimal_cnf_from_input('(A|B)&A', Minimal).

test(minimal_cnf_removes_tautological_clause,
     true(Minimal == var('B'))) :-
    minimal_cnf_from_input('(A|~A)&B', Minimal).

test(minimal_cnf_preserves_non_subsumed_structure,
     true(Minimal == and(var('A'), or(var('B'), var('C'))))) :-
    minimal_cnf_from_input('A&(B|C)', Minimal).

test(minimal_dnf_removes_subsumed_term_left_associative,
     true(Minimal == var('A'))) :-
    minimal_dnf_from_input('A|(A&B)', Minimal).

test(minimal_dnf_removes_subsumed_term_right_associative,
     true(Minimal == var('A'))) :-
    minimal_dnf_from_input('(A&B)|A', Minimal).

test(minimal_dnf_removes_contradictory_term,
     true(Minimal == var('B'))) :-
    minimal_dnf_from_input('(A&~A)|B', Minimal).

test(minimal_dnf_preserves_non_subsumed_structure,
     true(Minimal == or(var('A'), and(var('B'), var('C'))))) :-
    minimal_dnf_from_input('A|(B&C)', Minimal).

test(minimal_cnf_pretty_formats_reduced_result,
     true(Pretty == 'A')) :-
    minimal_cnf_pretty_from_input('A&(A|B)', Pretty).

test(minimal_dnf_pretty_formats_reduced_result,
     true(Pretty == 'A')) :-
    minimal_dnf_pretty_from_input('A|(A&B)', Pretty).

test(minimal_reported_tautology_dnf, true(Pretty == 'true')) :-
    minimal_dnf_pretty_from_input('((~B -> B) | (~((E & B)) | ~B))', Pretty).

test(minimal_reported_tautology_cnf, true(Pretty == 'true')) :-
    minimal_cnf_pretty_from_input('((~B -> B) | (~((E & B)) | ~B))', Pretty).

test(minimal_dnf_tautology_complement, true(Pretty == 'true')) :-
    minimal_dnf_pretty_from_input('B | ~B', Pretty).

test(minimal_cnf_tautology_complement, true(Pretty == 'true')) :-
    minimal_cnf_pretty_from_input('B | ~B', Pretty).

test(minimal_dnf_contradiction_complement, true(Pretty == 'false')) :-
    minimal_dnf_pretty_from_input('B & ~B', Pretty).

test(minimal_cnf_contradiction_complement, true(Pretty == 'false')) :-
    minimal_cnf_pretty_from_input('B & ~B', Pretty).

test(minimal_dnf_combines_complementary_terms, true(Pretty == 'A')) :-
    minimal_dnf_pretty_from_input('(A & B) | (A & ~B)', Pretty).

test(minimal_cnf_combines_complementary_clauses, true(Pretty == 'A')) :-
    minimal_cnf_pretty_from_input('(A | B) & (A | ~B)', Pretty).

test(minimal_dnf_absorption, true(Pretty == 'A')) :-
    minimal_dnf_pretty_from_input('A | (A & B)', Pretty).

test(minimal_cnf_absorption, true(Pretty == 'A')) :-
    minimal_cnf_pretty_from_input('A & (A | B)', Pretty).

test(minimal_dnf_combines_left_complement, true(Pretty == 'B')) :-
    minimal_dnf_pretty_from_input('(A & B) | (~A & B)', Pretty).

test(minimal_cnf_combines_left_complement, true(Pretty == 'B')) :-
    minimal_cnf_pretty_from_input('(A | B) & (~A | B)', Pretty).

test(minimal_constants_reduce_cleanly) :-
    minimal_dnf_pretty_from_input('true | A', 'true'),
    minimal_cnf_pretty_from_input('true | A', 'true'),
    minimal_dnf_pretty_from_input('false | A', 'A'),
    minimal_cnf_pretty_from_input('false | A', 'A'),
    minimal_dnf_pretty_from_input('true & A', 'A'),
    minimal_cnf_pretty_from_input('true & A', 'A'),
    minimal_dnf_pretty_from_input('false & A', 'false'),
    minimal_cnf_pretty_from_input('false & A', 'false').

test(minimal_implication_and_equivalence_edge_cases) :-
    minimal_dnf_pretty_from_input('~A -> A', 'A'),
    minimal_cnf_pretty_from_input('~A -> A', 'A'),
    minimal_dnf_pretty_from_input('A -> ~A', '~A'),
    minimal_cnf_pretty_from_input('A -> ~A', '~A'),
    minimal_dnf_pretty_from_input('A <-> ~A', 'false'),
    minimal_cnf_pretty_from_input('A <-> ~A', 'false'),
    minimal_dnf_pretty_from_input('A <-> A', 'true'),
    minimal_cnf_pretty_from_input('A <-> A', 'true').

test(minimal_known_cases_are_equivalent_and_bruteforce_minimal) :-
    forall(member(Input,
                  ['((~B -> B) | (~((E & B)) | ~B))',
                   'B | ~B',
                   'B & ~B',
                   '(A & B) | (A & ~B)',
                   '(A | B) & (A | ~B)',
                   'A | (A & B)',
                   'A & (A | B)',
                   '(A & B) | (~A & B)',
                   '(A | B) & (~A | B)',
                   '(A & B & C) | (A & B & ~C)',
                   '(A | B | C) & (A | B | ~C)']),
           check_minimal_forms(Input)).

test(randomized_minimal_forms_preserve_truth_and_small_minimality) :-
    set_random(seed(20260423)),
    forall(between(1, 30, _), check_random_minimal_case).

:- end_tests(minimal).

:- begin_tests(tseitin).

test(tseitin_formula_is_deterministic_for_simple_implication,
     true(Clauses ==
          and(and(or(x1, 'A'),
                  and(or(x1, not('B')),
                      or(not(x1), not('A'), 'B'))),
              x1))) :-
    tseitin_formula('A->B', Clauses).

test(tseitin_annotated_tree_marks_operator_nodes,
     true(Tree == node(x1, and, leaf('A'), leaf('B')))) :-
    tseitin_annotated_tree('A&B', Tree).

test(tseitin_pretty_formats_symbol_output,
     true(Pretty == 'x1 & (B | ~(A) | ~(x1)) & (~(B) | x1) & (A | x1)')) :-
    tseitin_pretty_from_input('A->B', Pretty).

test(tseitin_node_pretty_info_reports_equivalence_and_clauses,
     true(EqPretty-ClausePretty ==
          '(x1 <-> B & A)'-'(~(B) | ~(A) | x1) & (B | ~(x1)) & (A | ~(x1))')) :-
    tseitin_node_pretty_info('A&B', x1, EqPretty, ClausePretty).

:- end_tests(tseitin).

:- begin_tests(equivalence).

test(equivalent_implication_and_disjunction,
     true(Equivalent-Counterexample == true-[])) :-
    logical_equivalence_report('A -> B', '~A | B', Vars, Rows, Equivalent, Counterexample),
    Vars == ['A', 'B'],
    length(Rows, 4).

test(non_equivalent_formulas_report_counterexample,
     true(Equivalent-Counterexample == false-[0, 1, 0, 1])) :-
    logical_equivalence_report('A & B', 'A | B', ['A', 'B'], _, Equivalent, Counterexample).

test(equivalence_uses_variables_from_both_formulas,
     true(Vars == ['A', 'B'])) :-
    logical_equivalence_report('A', 'A & B', Vars, _, false, _).

test(equivalent_constants) :-
    logical_equivalent('A | ~A', 'true'),
    logical_equivalent('A & ~A', 'false').

test(rejects_invalid_equivalence_input, [fail]) :-
    silently(logical_equivalence_report('A &', 'A', _, _, _, _)).

:- end_tests(equivalence).

:- begin_tests(parser_predicate).

test(parses_quantified_predicate_formula,
     true(AST == forall(var(x), pred('P', [var(x)])))) :-
    parse_predicate_formula('forall x. P(x)', AST).

test(classifies_constants_functions_and_free_variables,
     true(AST == pred('P', [const(a), func(f, [var(x)]), var('Z')]))) :-
    parse_predicate_formula('P(a,f(x),Z)', AST).

test(preserves_bare_atom_as_propositional_style_variable,
     true(AST == var('R'))) :-
    parse_predicate_formula('R', AST).

test(rejects_missing_quantifier_dot, [fail]) :-
    silently(parse_predicate_formula('forall x P(x)', _)).

:- end_tests(parser_predicate).

:- begin_tests(prenex).

test(prenex_eliminates_implication_and_pulls_quantifiers,
     true(Prenex ==
          forall(var(x_1),
                 exists(var(y_2),
                        or(not(pred('P', [var(x_1)])),
                           pred('Q', [var(y_2)])))))) :-
    prenex_normal_form('forall x. (P(x) -> exists y. Q(y))', Prenex).

test(prenex_standardizes_apart_reused_bound_variables,
     true(Prenex ==
          exists(var(x_1),
                 forall(var(x_2),
                        and(pred('P', [var(x_1)]),
                            pred('Q', [var(x_2)])))))) :-
    prenex_normal_form('exists x. (P(x) & forall x. Q(x))', Prenex).

test(prenex_pushes_negation_through_quantifiers,
     true(Prenex ==
          exists(var(x_1),
                 exists(var(y_2),
                        and(not(pred('P', [var(x_1)])),
                            not(pred('R', [var(y_2)]))))))) :-
    prenex_normal_form('exists x. ~(P(x) | forall y. R(y))', Prenex).

test(rejects_invalid_predicate_input, [fail]) :-
    silently(prenex_normal_form('forall x P(x)', _)).

:- end_tests(prenex).
