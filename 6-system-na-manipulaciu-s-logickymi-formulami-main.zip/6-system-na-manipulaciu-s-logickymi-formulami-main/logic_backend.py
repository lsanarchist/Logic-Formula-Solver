import ast
import random
import re
from pathlib import Path
from typing import Any

from pyswip import Prolog

from formula_frontend import (
    build_karnaugh_map,
    build_normal_form_table,
    prolog_ast_to_exprnode,
)
from input_normalization import (
    get_shortcut_suggestions,
    normalize_formula_for_prolog,
    normalize_formula_input,
)

PROJECT_ROOT = Path(__file__).resolve().parent
PARSER_FILE = PROJECT_ROOT / "parser_propositional.pl"
PREDICATE_PARSER_FILE = PROJECT_ROOT / "parser_predicate.pl"
CNF_DNF_FILE = PROJECT_ROOT / "cnf_dnf_mimi.pl"
CANONICAL_FILE = PROJECT_ROOT / "canonical.pl"
MINIMAL_FILE = PROJECT_ROOT / "minimal.pl"
TRUTH_TABLE_FILE = PROJECT_ROOT / "truth_table.pl"
TSEITIN_FILE = PROJECT_ROOT / "tseitin.pl"
EQUIVALENCE_FILE = PROJECT_ROOT / "equivalence.pl"
PRENEX_FILE = PROJECT_ROOT / "prenex.pl"
SKOLEM_FILE = PROJECT_ROOT / "skolem.pl"

_QUANTIFIER_TOKEN_RE = re.compile(
    r"\bforall\b|\bexists\b|∀|∃",
    flags=re.IGNORECASE,
)


def shortcut_suggestions() -> list[dict[str, object]]:
    return get_shortcut_suggestions()


def normalize_display_formula(formula: str) -> str:
    return normalize_formula_input(formula)


def _to_prolog_atom(text: str) -> str:
    escaped = text.replace("\\", "\\\\").replace("'", "''")
    return f"'{escaped}'"


def _prepare_formula_input(formula: str) -> str:
    normalized = normalize_formula_for_prolog(formula).strip()
    if not normalized:
        raise ValueError("Formula cannot be empty.")
    return normalized


def predicate_formula_has_quantifiers(formula: str) -> bool:
    if not formula or not formula.strip():
        return False
    return bool(_QUANTIFIER_TOKEN_RE.search(normalize_formula_input(formula)))


def generate_random_formula() -> str:
    variables = random.sample(["A", "B", "C", "D", "E", "F"], k=random.randint(2, 4))
    expr = _random_formula_expr(depth=random.randint(2, 4), variables=variables, force_binary=True)
    return _random_formula_to_text(expr)


def _random_formula_expr(
    depth: int,
    variables: list[str],
    force_binary: bool = False,
) -> str | tuple[Any, ...]:
    if depth <= 0:
        return random.choice(variables)

    if not force_binary and random.random() < 0.30:
        return random.choice(variables)

    if not force_binary and random.random() < 0.24:
        return ("not", _random_formula_expr(depth - 1, variables))

    operator = random.choices(
        ["and", "or", "imp", "iff"],
        weights=[4, 4, 2, 1],
        k=1,
    )[0]
    left = _random_formula_expr(depth - 1, variables)
    right = _random_formula_expr(depth - 1, variables)

    if left == right and operator in {"imp", "iff"} and len(variables) > 1:
        alternatives = [var for var in variables if var != left]
        if alternatives:
            right = random.choice(alternatives)

    return (operator, left, right)


def _random_formula_to_text(expr: str | tuple[Any, ...]) -> str:
    if isinstance(expr, str):
        return expr
    if isinstance(expr, tuple) and len(expr) == 2 and expr[0] == "not":
        child = expr[1]
        child_text = _random_formula_to_text(child)
        if isinstance(child, tuple) and len(child) == 3:
            return f"¬({child_text})"
        return f"¬{child_text}"
    if isinstance(expr, tuple) and len(expr) == 3:
        op, left, right = expr
        symbol = {
            "and": " ∧ ",
            "or": " ∨ ",
            "imp": " ⇒ ",
            "iff": " ⇔ ",
        }[op]
        left_text = _random_formula_to_text(left)
        right_text = _random_formula_to_text(right)
        return f"({left_text}{symbol}{right_text})"
    raise ValueError("Unexpected random formula expression.")


def get_prolog() -> Prolog:
    prolog = Prolog()
    prolog.consult(str(PARSER_FILE))
    prolog.consult(str(PREDICATE_PARSER_FILE))
    prolog.consult(str(CNF_DNF_FILE))
    prolog.consult(str(CANONICAL_FILE))
    prolog.consult(str(MINIMAL_FILE))
    prolog.consult(str(TRUTH_TABLE_FILE))
    prolog.consult(str(TSEITIN_FILE))
    prolog.consult(str(EQUIVALENCE_FILE))
    prolog.consult(str(PRENEX_FILE))
    prolog.consult(str(SKOLEM_FILE))
    return prolog


def parse_formula_expr(formula: str):
    normalized = _prepare_formula_input(formula)
    if normalized.lower() in {"true", "false"}:
        return prolog_ast_to_exprnode(normalized.lower())

    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    parse_result = list(
        prolog.query(f"parse_propositional_formula({prolog_input}, AST)", maxresult=1)
    )
    if not parse_result:
        raise ValueError("Parsing failed for this input.")
    return prolog_ast_to_exprnode(parse_result[0]["AST"])


def analyze_formula(formula: str) -> tuple[str, str]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()

    token_result = list(prolog.query(f"tokenize({prolog_input}, Tokens)", maxresult=1))
    parse_result = list(
        prolog.query(f"parse_propositional_formula({prolog_input}, AST)", maxresult=1)
    )

    if not token_result:
        raise ValueError("Tokenization failed for this input.")
    if not parse_result:
        raise ValueError("Parsing failed for this input.")

    tokens = str(token_result[0]["Tokens"])
    ast_text = str(parse_result[0]["AST"])
    return tokens, ast_text


def cnf_formula(formula: str) -> str:
    return _pretty_from_input(formula, "cnf_pretty_from_input", "CNF conversion")


def dnf_formula(formula: str) -> str:
    return _pretty_from_input(formula, "dnf_pretty_from_input", "DNF conversion")


def canonical_cnf_formula(formula: str) -> str:
    return _pretty_from_input(
        formula,
        "canonical_cnf_pretty_from_input",
        "Canonical CNF conversion",
    )


def canonical_dnf_formula(formula: str) -> str:
    return _pretty_from_input(
        formula,
        "canonical_dnf_pretty_from_input",
        "Canonical DNF conversion",
    )


def minimal_cnf_formula(formula: str) -> str:
    return _pretty_from_input(
        formula,
        "minimal_cnf_pretty_from_input",
        "Minimal CNF conversion",
    )


def minimal_dnf_formula(formula: str) -> str:
    return _pretty_from_input(
        formula,
        "minimal_dnf_pretty_from_input",
        "Minimal DNF conversion",
    )


def _pretty_from_input(formula: str, predicate: str, label: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"{predicate}({prolog_input}, Pretty)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(f"{label} failed for this input.")
    return _ascii_ops_to_unicode(str(result[0]["Pretty"]))


def normal_form_details(
    formula_text: str,
    normal_form: str,
    source_formula: str | None = None,
) -> dict[str, Any]:
    details: dict[str, Any] = {
        "rows": None,
        "summary": None,
        "table_error": None,
        "karnaugh_map": None,
        "karnaugh_error": None,
    }

    try:
        rows, summary = build_normal_form_table(
            formula_text,
            parse_expr=parse_formula_expr,
            normal_form=normal_form,
            source_formula=source_formula,
        )
    except Exception as exc:
        details["table_error"] = str(exc)
    else:
        details["rows"] = rows
        details["summary"] = summary

    try:
        details["karnaugh_map"] = build_karnaugh_map(
            formula_text,
            parse_expr=parse_formula_expr,
            normal_form=normal_form,
            source_formula=source_formula,
        )
    except Exception as exc:
        details["karnaugh_error"] = str(exc)

    return details


def _swipl_atom_str(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    text = str(value)
    if len(text) >= 2 and text[0] == text[-1] == "'":
        return text[1:-1]
    return text


def _truth_table_cell_char(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, bytes):
        raw = value.decode("utf-8", errors="replace").lower()
        if raw == "na":
            return "-"
        if raw in {"true", "false"}:
            return "1" if raw == "true" else "0"
    if isinstance(value, str) and value.lower() == "na":
        return "-"
    if value is True:
        return "1"
    if value is False:
        return "0"
    if isinstance(value, int):
        if value == 1:
            return "1"
        if value == 0:
            return "0"
        if value == -1:
            return "-"
    text = _swipl_atom_str(value).lower()
    if text in {"true", "1"}:
        return "1"
    if text in {"false", "0"}:
        return "0"
    if text == "na":
        return "-"
    return "-"


def _truth_table_bits_list(raw: object) -> list[object]:
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return list(raw)
    if hasattr(raw, "args"):
        return list(getattr(raw, "args") or ())
    return [raw]


def _prolog_list_to_python_list(raw: object) -> list[object]:
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return list(raw)
    if hasattr(raw, "args"):
        return list(getattr(raw, "args") or ())
    return []


def _prolog_list_to_text_list(raw: object) -> list[str]:
    return [_swipl_atom_str(item) for item in _prolog_list_to_python_list(raw)]


def _truth_table_unpack_row(
    raw: object,
) -> tuple[list[object], object, object, object] | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        inner = raw.strip()
        if inner.startswith("[") and inner.endswith("]"):
            try:
                parsed = ast.literal_eval(inner)
            except (SyntaxError, ValueError):
                parsed = None
            if isinstance(parsed, list) and len(parsed) >= 3:
                *bits_vals, f_v, md_v, mc_v = parsed
                return (list(bits_vals), f_v, md_v, mc_v)
        return None
    if isinstance(raw, (list, tuple)) and len(raw) >= 3:
        seq = list(raw)
        bits_vals, f_v, md_v, mc_v = seq[:-3], seq[-3], seq[-2], seq[-1]
        return (list(bits_vals), f_v, md_v, mc_v)
    if hasattr(raw, "args"):
        args = getattr(raw, "args")
        if args is not None and len(args) == 4:
            bits_raw, f_v, md_v, mc_v = args
            return (_truth_table_bits_list(bits_raw), f_v, md_v, mc_v)
    return None


def _truth_table_unpack_props(raw: object) -> dict[str, object]:
    if raw is None:
        raise ValueError("Unexpected truth-table summary from Prolog.")
    if isinstance(raw, (list, tuple)) and len(raw) == 8:
        args = raw
    elif hasattr(raw, "args") and getattr(raw, "args") is not None:
        args = tuple(getattr(raw, "args"))
        if len(args) != 8:
            raise ValueError("Unexpected truth-table summary from Prolog.")
    else:
        raise ValueError("Unexpected truth-table summary from Prolog.")

    (
        classification,
        is_tautology,
        is_contradiction,
        is_satisfiable,
        equiv,
        mdnf_ok,
        mcnf_ok,
        message,
    ) = args
    return {
        "classification": _swipl_atom_str(classification),
        "is_tautology": is_tautology is True or _swipl_atom_str(is_tautology).lower() == "true",
        "is_contradiction": is_contradiction is True
        or _swipl_atom_str(is_contradiction).lower() == "true",
        "is_satisfiable": is_satisfiable is True
        or _swipl_atom_str(is_satisfiable).lower() == "true",
        "equivalent_mdnf_mcnf": equiv is True or _swipl_atom_str(equiv).lower() == "true",
        "mdnf_available": mdnf_ok is True or _swipl_atom_str(mdnf_ok).lower() == "true",
        "mcnf_available": mcnf_ok is True or _swipl_atom_str(mcnf_ok).lower() == "true",
        "minimal_message": _repair_swipl_utf8_mojibake(_swipl_atom_str(message)),
    }


def truth_table_bundle(
    formula: str,
) -> tuple[list[dict[str, str]], str, str, dict[str, bool | str]]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            "truth_table_report("
            f"{prolog_input}, VarNames, Rows, MDNFPretty, MCNFPretty, Props)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError("Truth table computation failed for this input.")

    binding = result[0]
    var_names_raw = binding["VarNames"]
    rows_raw = binding["Rows"]
    mdnf_text = _ascii_ops_to_unicode(_repair_swipl_utf8_mojibake(_swipl_atom_str(binding["MDNFPretty"])))
    mcnf_text = _ascii_ops_to_unicode(_repair_swipl_utf8_mojibake(_swipl_atom_str(binding["MCNFPretty"])))
    props_core = _truth_table_unpack_props(binding["Props"])

    var_names: list[str] = []
    if isinstance(var_names_raw, (list, tuple)):
        var_names = [_swipl_atom_str(v) for v in var_names_raw]
    elif var_names_raw is not None and hasattr(var_names_raw, "args"):
        var_names = [_swipl_atom_str(v) for v in (var_names_raw.args or ())]

    if isinstance(rows_raw, (list, tuple)):
        rows_in = list(rows_raw)
    elif rows_raw is not None and hasattr(rows_raw, "args"):
        rows_in = list(rows_raw.args or ())
    else:
        rows_in = []

    table_rows: list[dict[str, str]] = []
    for raw_row in rows_in:
        unpacked = _truth_table_unpack_row(raw_row)
        if unpacked is None:
            continue
        bits_vals, f_v, md_v, mc_v = unpacked
        row: dict[str, str] = {}
        for name, bit in zip(var_names, bits_vals):
            row[name] = _truth_table_cell_char(bit)
        row["F"] = _truth_table_cell_char(f_v)
        row["MDNF"] = _truth_table_cell_char(md_v)
        row["MCNF"] = _truth_table_cell_char(mc_v)
        table_rows.append(row)

    mdnf_ok = bool(props_core["mdnf_available"])
    mcnf_ok = bool(props_core["mcnf_available"])
    table_props: dict[str, bool | str] = {
        "is_tautology": bool(props_core["is_tautology"]),
        "is_contradiction": bool(props_core["is_contradiction"]),
        "is_satisfiable": bool(props_core["is_satisfiable"]),
        "equivalent_mdnf_mcnf": bool(props_core["equivalent_mdnf_mcnf"]),
        "classification": str(props_core["classification"]),
        "minimal_available": mdnf_ok and mcnf_ok,
        "minimal_any_available": mdnf_ok or mcnf_ok,
        "mdnf_available": mdnf_ok,
        "mcnf_available": mcnf_ok,
        "minimal_message": str(props_core["minimal_message"]),
    }
    return table_rows, mdnf_text, mcnf_text, table_props


def logical_equivalence_report(formula_a: str, formula_b: str) -> dict[str, Any]:
    normalized_a = _prepare_formula_input(formula_a)
    normalized_b = _prepare_formula_input(formula_b)
    prolog_input_a = _to_prolog_atom(normalized_a)
    prolog_input_b = _to_prolog_atom(normalized_b)
    prolog = get_prolog()
    result = list(
        prolog.query(
            "logical_equivalence_report("
            f"{prolog_input_a}, {prolog_input_b}, VarNames, Rows, Equivalent, Counterexample)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError("Logical equivalence check failed for these inputs.")

    binding = result[0]
    var_names = _prolog_list_to_text_list(binding["VarNames"])
    rows_raw = _prolog_list_to_python_list(binding["Rows"])
    counterexample_raw = _prolog_list_to_python_list(binding["Counterexample"])
    equivalent = _swipl_atom_str(binding["Equivalent"]).lower() == "true"

    columns = [*var_names, "Formula 1", "Formula 2"]
    rows: list[dict[str, str]] = []
    for raw_row in rows_raw:
        values = _prolog_list_to_python_list(raw_row)
        if len(values) != len(var_names) + 2:
            continue
        row = {
            column: _truth_table_cell_char(value)
            for column, value in zip(columns, values)
        }
        rows.append(row)

    counterexample: dict[str, str] | None = None
    if counterexample_raw:
        counterexample = {
            column: _truth_table_cell_char(value)
            for column, value in zip(columns, counterexample_raw)
        }

    return {
        "equivalent": equivalent,
        "variables": var_names,
        "columns": columns,
        "rows": rows,
        "counterexample": counterexample,
    }


def skolem_pretty_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"skolem_pretty_from_input({prolog_input}, Pretty)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(
            "Skolemov normalny tvar zlyhal. Skuste predikatovu formulu "
            "(napr. `forall x. P(x)` s bodkou po kvantifikatore)."
        )
    return _repair_swipl_utf8_mojibake(str(result[0]["Pretty"]))


def skolem_steps_pretty(formula: str) -> tuple[str, str]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"skolem_steps_pretty({prolog_input}, PrenexPretty, SkolemPretty)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(
            "Skolemov krok zlyhal. Skuste platnu predikatovu formulu "
            "s kvantifikatormi (`forall x. ...`, `exists y. ...`)."
        )
    return (
        _ascii_ops_to_unicode(_repair_swipl_utf8_mojibake(str(result[0]["PrenexPretty"]))),
        _ascii_ops_to_unicode(_repair_swipl_utf8_mojibake(str(result[0]["SkolemPretty"]))),
    )


def prenex_formula(formula: str) -> str:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"prenex_normal_form({prolog_input}, PrenexAst), skolem_ast_to_pretty(PrenexAst, Pretty)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(
            "Prenex form failed. Try a valid predicate formula "
            "such as `forall x. (P(x) -> exists y. Q(y))`."
        )
    return _ascii_ops_to_unicode(_repair_swipl_utf8_mojibake(str(result[0]["Pretty"])))


def formula_tree(formula: str) -> dict[str, Any]:
    expr = parse_formula_expr(formula)
    return _exprnode_to_tree_dict(expr)


def predicate_formula_tree(formula: str) -> dict[str, Any]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()
    result = list(
        prolog.query(
            f"parse_predicate_formula({prolog_input}, AST), term_string(AST, ASTText)",
            maxresult=1,
        )
    )
    if not result:
        raise ValueError(
            "Predicate formula parsing failed. Use quantifiers like "
            "`forall x. P(x)` or `exists y. Q(y)`."
        )
    return _predicate_ast_to_tree_dict(_parse_term(_prolog_text(result[0]["ASTText"])))


def _split_args(s: str) -> list[str]:
    args: list[str] = []
    depth = 0
    buf: list[str] = []
    in_q = False
    for char in s:
        if char == "'" and not in_q:
            in_q = True
            buf.append(char)
        elif char == "'" and in_q:
            in_q = False
            buf.append(char)
        elif in_q:
            buf.append(char)
        elif char in "([":
            depth += 1
            buf.append(char)
        elif char in ")]":
            depth -= 1
            buf.append(char)
        elif char == "," and depth == 0:
            args.append("".join(buf).strip())
            buf = []
        else:
            buf.append(char)
    if buf:
        args.append("".join(buf).strip())
    return args


def _parse_term(s: str):
    s = s.strip()
    if s.startswith("'") and s.endswith("'") and len(s) >= 2:
        return s[1:-1]
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [_parse_term(arg) for arg in _split_args(inner)]
    p = s.find("(")
    if p == -1:
        return s
    functor = s[:p].strip()
    inner = s[p + 1 : s.rfind(")")].strip()
    return (functor, [_parse_term(arg) for arg in _split_args(inner)])


def _tree_to_dict(t) -> dict[str, Any]:
    if isinstance(t, str):
        return {"type": "leaf", "label": t}

    functor, args = t

    if functor == "leaf" and len(args) == 1:
        a = args[0]
        if isinstance(a, tuple) and a[0] == "var" and a[1]:
            label = str(a[1][0])
        else:
            label = str(a)
        return {"type": "leaf", "label": label}

    if functor == "node1" and len(args) == 3:
        var_t, op_t, sub_t = args
        return {
            "type": "node",
            "label": str(op_t),
            "var": str(var_t),
            "children": [_tree_to_dict(sub_t)],
        }

    if functor == "node" and len(args) == 4:
        var_t, op_t, left_t, right_t = args
        return {
            "type": "node",
            "label": str(op_t),
            "var": str(var_t),
            "children": [_tree_to_dict(left_t), _tree_to_dict(right_t)],
        }

    return {"type": "leaf", "label": str(t)}


def _predicate_ast_to_tree_dict(t) -> dict[str, Any]:
    if isinstance(t, str):
        return {"type": "leaf", "label": t}

    functor, args = t

    if functor == "var" and len(args) == 1:
        return {"type": "leaf", "label": str(args[0])}

    if functor == "const" and len(args) == 1:
        return {"type": "leaf", "label": str(args[0])}

    if functor == "func" and len(args) == 2:
        name, term_args = args
        return _predicate_call_tree(str(name), term_args)

    if functor == "pred" and len(args) == 2:
        name, pred_args = args
        return _predicate_call_tree(str(name), pred_args)

    if functor in {"forall", "exists"} and len(args) == 2:
        quantifier = "\u2200" if functor == "forall" else "\u2203"
        variable = _predicate_term_label(args[0])
        return {
            "type": "node",
            "label": f"{quantifier}{variable}",
            "children": [_predicate_ast_to_tree_dict(args[1])],
        }

    if functor == "not" and len(args) == 1:
        return {
            "type": "node",
            "label": "not",
            "children": [_predicate_ast_to_tree_dict(args[0])],
        }

    if functor in {"and", "or", "imp", "iff"} and len(args) == 2:
        return {
            "type": "node",
            "label": functor,
            "children": [
                _predicate_ast_to_tree_dict(args[0]),
                _predicate_ast_to_tree_dict(args[1]),
            ],
        }

    return {"type": "leaf", "label": _predicate_term_label(t)}


def _predicate_call_tree(name: str, args: Any) -> dict[str, Any]:
    arg_list = args if isinstance(args, list) else []
    if not arg_list:
        return {"type": "leaf", "label": name}
    return {
        "type": "node",
        "label": name,
        "children": [_predicate_term_to_tree_dict(arg) for arg in arg_list],
    }


def _predicate_term_to_tree_dict(t: Any) -> dict[str, Any]:
    if isinstance(t, str):
        return {"type": "leaf", "label": t}
    if not isinstance(t, tuple):
        return {"type": "leaf", "label": str(t)}

    functor, args = t
    if functor in {"var", "const"} and len(args) == 1:
        return {"type": "leaf", "label": str(args[0])}
    if functor == "func" and len(args) == 2:
        return _predicate_call_tree(str(args[0]), args[1])
    return {"type": "leaf", "label": _predicate_term_label(t)}


def _predicate_call_label(name: str, args: Any) -> str:
    arg_list = args if isinstance(args, list) else []
    if not arg_list:
        return name
    return f"{name}({', '.join(_predicate_term_label(arg) for arg in arg_list)})"


def _predicate_term_label(t: Any) -> str:
    if isinstance(t, str):
        return t
    if not isinstance(t, tuple):
        return str(t)

    functor, args = t
    if functor in {"var", "const"} and len(args) == 1:
        return str(args[0])
    if functor == "func" and len(args) == 2:
        return _predicate_call_label(str(args[0]), args[1])
    return str(t)


def _exprnode_to_tree_dict(node) -> dict[str, Any]:
    if node is None:
        return {"type": "leaf", "label": "?"}

    if (
        getattr(node, "value", None) is not None
        and getattr(node, "left", None) is None
        and getattr(node, "right", None) is None
    ):
        return {
            "type": "leaf",
            "label": str(node.value),
        }

    children = []
    if getattr(node, "left", None) is not None:
        children.append(_exprnode_to_tree_dict(node.left))
    if getattr(node, "right", None) is not None:
        children.append(_exprnode_to_tree_dict(node.right))

    if not children and getattr(node, "value", None) is not None:
        return {
            "type": "leaf",
            "label": str(node.value),
        }

    return {
        "type": "node",
        "label": str(node.op),
        "children": children,
    }


def _prolog_text(value) -> str:
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8")
    return str(value)


def _ascii_ops_to_unicode(s: str) -> str:
    s = s.replace("<->", "⇔")
    s = s.replace("->", "⇒")
    s = s.replace(" & ", " ∧ ")
    s = s.replace(" | ", " ∨ ")
    s = s.replace("~(", "¬(")
    s = s.replace("~", "¬")
    s = re.sub(r"\btrue\b", "⊤", s)
    s = re.sub(r"\bfalse\b", "⊥", s)
    return s


def _repair_swipl_utf8_mojibake(s: str) -> str:
    if not s or "\u2203" in s or "\u2200" in s:
        return s
    try:
        return s.encode("latin-1").decode("utf-8")
    except (UnicodeDecodeError, UnicodeEncodeError):
        return s


def _collect_tseitin_vars(tree: dict[str, Any]) -> list[str]:
    result: list[str] = []

    def walk(node: dict[str, Any]) -> None:
        if not isinstance(node, dict):
            return
        if node.get("type") == "node" and node.get("var"):
            result.append(str(node["var"]))
        for child in node.get("children", []):
            walk(child)

    walk(tree)
    return result


def tseitin_transform(formula: str) -> tuple[dict[str, Any], str, dict[str, dict[str, str]]]:
    normalized = _prepare_formula_input(formula)
    prolog_input = _to_prolog_atom(normalized)
    prolog = get_prolog()

    tree_res = list(prolog.query(f"tseitin_annotated_tree({prolog_input}, Tree)", maxresult=1))
    if not tree_res:
        raise ValueError(
            "Tseitin transformation failed - check that the formula is valid. "
            "Supported operators: ~, &, |, ->, <->."
        )

    tree_raw = str(tree_res[0]["Tree"])
    tree_obj = _parse_term(tree_raw)
    tree_dict = _tree_to_dict(tree_obj)

    pretty_res = list(
        prolog.query(f"tseitin_pretty_from_input({prolog_input}, Pretty)", maxresult=1)
    )
    if not pretty_res:
        raise ValueError("Tseitin pretty output failed.")

    full_formula_str = _ascii_ops_to_unicode(_prolog_text(pretty_res[0]["Pretty"]))

    node_info_map: dict[str, dict[str, str]] = {}
    for var_name in _collect_tseitin_vars(tree_dict):
        var_atom = _to_prolog_atom(var_name)
        info_res = list(
            prolog.query(
                f"tseitin_node_pretty_info({prolog_input}, {var_atom}, EqPretty, ClauseFormulaPretty)",
                maxresult=1,
            )
        )
        if info_res:
            node_info_map[var_name] = {
                "equivalence": _ascii_ops_to_unicode(_prolog_text(info_res[0]["EqPretty"])),
                "clauses": _ascii_ops_to_unicode(_prolog_text(info_res[0]["ClauseFormulaPretty"])),
            }

    return tree_dict, full_formula_str, node_info_map
